----------------------------------------------------------------------------------------------------------------
-- 1) 
-- Create the TIMES star schema dimension table via SQL. This is “TIME” table in the star schema figure. 
-- The Sale_Day primary key column values should be all dates from your first sale date through and including 
-- your last sale date from your SALES table. The Day_Type values should be 'Weekday', 'Weekend', or 'Holiday' 
-- (this trumps Weekday and Weekend). Set all occurrences of the following days for your date range to be holidays: 
-- New Year’s Day, Martin Luther King Jr’s Birthday, President’s Day, Memorial Day, 4th of July, Labor Day, 
-- Columbus Day, Veterans Day, Thanksgiving, and Christmas. Use a PL/SQL block to populate the TIMES table.
--
-- After populating your TIMES table execute the SQL statement 
-- "SELECT day_type, COUNT(*),MIN(sale_day),MAX(sale_day) FROM time GROUP BY day_type ORDER BY day_type" 
-- to show the summarized contents of your table. 
----------------------------------------------------------------------------------------------------------------

CREATE TABLE times (
    sale_day date
    CONSTRAINT PK_sale_day PRIMARY KEY,
    day_type varchar(50) NOT NULL
    ----------------------------------------------------
    -- CHECKS
    ----------------------------------------------------
    CONSTRAINT CKH_day_type CHECK (day_type IN ('Weekday', 'Weekend', 'Holiday'))
);

----------------------------------------------------
-- Add all available dates and 
-- determine weekdays, weekends, and holidays
----------------------------------------------------
SET SERVEROUTPUT ON;

DECLARE
    sale_date date; -- actual date --
    short_date varchar(6); -- day + month --
    day_of_week varchar(3); 
    daytype varchar(10); -- day categories --
    -- Cursor
    CURSOR c1 IS
        SELECT DISTINCT sale_date, to_char(sale_date, 'DD') || to_char(sale_date, 'MON') short_date, to_char(sale_date, 'DY') day_of_week
        FROM sales
        ORDER BY sale_date ASC;
BEGIN
    OPEN c1;
    LOOP
        FETCH c1 INTO sale_date, short_date, day_of_week;
        EXIT WHEN c1%NOTFOUND;
        
        CASE
            -- Holidays --
            WHEN short_date IN ('01JAN', '16JAN', '20FEB', '30MAY', '04JUL', '05SEP', '10OCT', '11NOV', '24NOV', '25DEC') THEN
                daytype := 'Holiday';
            -- Weekends --
            WHEN day_of_week IN ('SAT', 'SUN') THEN
                daytype := 'Weekend';
            -- Weekdays --
            ELSE
                daytype := 'Weekday';
        END CASE;
        
        DBMS_OUTPUT.PUT_LINE(short_date || ': ' || daytype);
    
        INSERT INTO times
        VALUES (
            sale_date,
            daytype
        );
    
    END LOOP;
    CLOSE c1;

END;
/

----------------------------------------------------
-- Show results
----------------------------------------------------
SELECT 
    day_type, 
    COUNT(*), 
    MIN(sale_day), 
    MAX(sale_day) 
FROM times 
GROUP BY day_type 
ORDER BY day_type;

----------------------------------------------------------------------------------------------------------------
-- 2)
-- Create the SALES_FACTS star schema fact table via SQL. Ensure that you have declared foreign keys of Sale_Day, 
-- Vehicle_Code, Plan_Code, and Dealer_ID to reference your TIMES, VEHICLES, FINANCING_PLANS, 
-- and DEALERSHIPS tables, respectfully. Ensure that you have a primary key for the SALES_FACTS table that 
-- is a composite of the Sale_Day, Vehicle_Code, Plan_Code, and Dealer_ID columns. Do a DESC (i.e. DESCRIBE) of 
-- your SALES_FACTS table after it’s created. 
----------------------------------------------------------------------------------------------------------------

CREATE TABLE sales_facts (
    sale_day date,
    vehicle_code int,
    plan_id char(5),
    dealer_id varchar(8),
    vehicles_sold int,
    gross_sales_amt int,
    ----------------------------------------------------
    -- COMP PRIMARY KEY
    ----------------------------------------------------
    CONSTRAINT PK_sales_facts 
    PRIMARY KEY (sale_day, vehicle_code, plan_id, dealer_id),
    ----------------------------------------------------
    -- FOREIGN KEYS
    ----------------------------------------------------
    CONSTRAINT FK_facts_sale_day 
    FOREIGN KEY (sale_day) REFERENCES times (sale_day),
    CONSTRAINT FK_facts_vehicle_code
    FOREIGN KEY (vehicle_code) REFERENCES vehicles (vehicle_code),
    CONSTRAINT FK_facts_plan_id 
    FOREIGN KEY (plan_id) REFERENCES financing_plans (plan_id),
    CONSTRAINT FK_facts_dealer_id
    FOREIGN KEY (dealer_id) REFERENCES dealerships (dealer_id)
);

DESCRIBE sales_facts;

----------------------------------------------------------------------------------------------------------------
-- 3)
-- Ensure that the FINANCING_PLANS, DEALERSHIPS, VEHICLES, and TIMES dimension tables are all created and 
-- populated as required. Do a SELECT COUNT(*) FROM <table_name> for each of the four tables. 
----------------------------------------------------------------------------------------------------------------

SELECT COUNT(*) "Financing Plans Count"
FROM financing_plans;

SELECT COUNT(*) "Dealerships Count"
FROM dealerships;

SELECT COUNT(*) "Vehicle Count"
FROM vehicles;

SELECT COUNT(*) "Times Count"
FROM times;

----------------------------------------------------------------------------------------------------------------
-- 4)
-- Using PL/SQL stored procedure populate the SALES_FACTS table. One way to do this is to use four nested 
-- cursor loops to get every possible combination of the dimension tables’ primary keys and then the total 
-- vehicles sold and gross sales amount for each combination. If these values for Total_Vehicles_Sold and 
-- Gross_Sales_Amount for a combination are zero then don’t INSERT a row into the SALES_FACT table. 
-- Only insert rows for combinations of the four foreign key columns where there were some vehicles sold.
--
-- Another approach besides nested cursor loops is to use a single INSERT statement with a GROUP BY clause. 
-- After populating your SALES_FACTS table execute the query “SELECT COUNT(*) FROM sales_facts;” to 
-- show the row count. Also execute the query “SELECT SUM(vehicles_sold) FROM sales_facts;” to ensure that you 
-- have included all of your 200 or more sales. 
----------------------------------------------------------------------------------------------------------------

