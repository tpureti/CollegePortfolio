/*
		Your Name: Thushara Pureti
		Last Modified Date: 05/10/2021
		File: event_registration.js
		File Description: scripting
*/

// Set the minimum and maximum number of tickets able to be purchased
let minTickets = 1;
let maxTickets = 3;
// Set variables for the ticket cost
let costPerTicket = 5.00;
let ticketSurcharge = 0.50;

/* TIMER FUNCTIONALITY */ 
let startTimer = (duration, display) => {
		//variable that sets timer format
  let timer = duration, minutes, seconds;
		//setInterval method
  setInterval(() => {
			/* parseInt converts strings (the written numbers in HTML) into integers */

			//minutes = timer duration divided by 60 in base-10
    	minutes = parseInt(timer / 60, 10)
			//seconds = timer duration remainder of 60 in base-10
    	seconds = parseInt(timer % 60, 10)

			/* Conditional ternany operator
			if minutes/seconds < 10 (the condition) ? 
			"0"(string) + minutes (show if true) :
			minutes (show if false) */
    	minutes = minutes < 10 ? "0" + minutes : minutes //show 0 before minutes if minutes are less than 10
			seconds = seconds < 10 ? "0" + seconds : seconds //show 0 before seconds if seconds are less than 10

			//displays the timer in correct format
      display.textContent = minutes + ":" + seconds;

				//if statement, using a -- to decrement the time by one second
      if (--timer == 0) {
					//when timer reaches 0, show alert
					alert('Your time has run out. Please try again.')
					//and reload page
					location.reload();
        }
    }, 1000);
}

//starts after window finishes loading
window.onload = () => {
		//variable for 10 minutes
    let tenMinutes = 60 * 10,
		//variable for timer display
    display = document.querySelector('#timer');
		//call function with 10 minute parameter and display		
    startTimer(tenMinutes, display);
};

/* ERROR FUNCTIONS */
//function to change input color when there is an error
function inputError() {
	let inputs = document.querySelectorAll('input[type=text]')
	let emailInput = document.querySelector('#email');

	inputs.forEach(input => {
		input.style.backgroundColor = "#f75f54";
 		})
	
	emailInput.style.backgroundColor = "#f75f54";
}

//function to change input color back to default when there is no error
function removeInputError() {
	let inputs = document.querySelectorAll('input[type=text]');
	let emailInput = document.querySelector('#email');

	inputs.forEach(input => {
		input.style.backgroundColor = "#efefef";
 		})

	emailInput.style.backgroundColor = "#efefef";	 
}

/* FUNCTION WHICH CALCULATES TOTAL BASED ON NUMBER OF TICKETS */
function calculateTotal() {
	//gets the value of the number typed
	let numTickets = document.querySelector('#numTickets').value;
	//changes string into integer
	let ticketNumber = parseInt(numTickets, 10);
	let contactInfo = document.querySelector('#contactInformation');

	//cost calculator with $ before it and shows two decimal points
	let total = '$' + (ticketNumber * (costPerTicket + ticketSurcharge)).toFixed(2);
			
	//changes value of total cost
	document.querySelector('#totalCost').value=total;

	/* IF/ELSE STATEMENT */
	//first checks to see if ticketNumber is a valid number, when falsy:
	if (isNaN(ticketNumber)) { 
	//changes value to invalid	
	document.querySelector('#totalCost').value='Invalid'
	//displays an error message
	document.querySelector('#msgTickets').innerText = 'Not a valid number'
	//changes input field to red when there is an error
	inputError()
	//hides contact info
	contactInfo.style.display = "none";
	}

	//second checks to see if ticketNumber is between 1 and 3 tickers, when falsy:
	else if (ticketNumber < minTickets || ticketNumber > maxTickets || ticketNumber == '') {
		//displays an error message
		document.querySelector('#msgTickets').innerText = 'You can only buy between 1 and 3 tickets'
		//changes input field to red when there is an error
		inputError()
		//hides contact info
		contactInfo.style.display = "none";
	}

	//when both conditions are truthy
	 else {
		//removes any error messages
		document.querySelector('#msgTickets').innerText = ''
		//removes red input field
		removeInputError()
		//shows contact info
		contactInfo.style.display = "block";
	}
}

/* FUNCTION WHICH VALIDATES UPON CLICKING SUBMIT */
function completePurchase() {
//declare contact info variables
let inputName = document.querySelector('#name');
let inputEmail = document.querySelector('#email'); 
let inputTickets = document.querySelector('#numTickets');

//redeclare values to calculate total
let numTickets = document.querySelector('#numTickets').value;
let ticketNumber = parseInt(numTickets, 10);

//ticket total
let total = '$' + (ticketNumber * (costPerTicket + ticketSurcharge)).toFixed(2);

//add required attribute upon click
inputName.setAttribute('required', 'true');
inputEmail.setAttribute('required', 'true');
inputTickets.setAttribute('required', 'true');

//changes background + error message if input is empty
inputName.oninput = nameValidation;
inputEmail.oninput = emailValidation;
inputTickets.oninput = ticketValidation; 

//adds error message upon submit
inputName.addEventListener('input', nameValidation());
inputEmail.addEventListener('input', emailValidation());
inputTickets.addEventListener('input', ticketValidation()); 

/* The following functions validate the name, email, and ticket inputs */
function nameValidation() {
	if (inputName.validity.valueMissing) {
			document.querySelector('#msgname').innerText = "You must enter your name"
			inputError();
		}

		else {
			document.querySelector('#msgname').innerText = ""
			removeInputError();
		}
}

function emailValidation() {
	if (inputEmail.validity.valueMissing) {
			document.querySelector('#msgemail').innerText = "You must enter your email"
			inputError();
		}

		else {
			document.querySelector('#msgemail').innerText = ""
			removeInputError();
		}
	}

	function ticketValidation() {
	if (inputTickets.validity.valueMissing) {
			document.querySelector('#msgTickets').innerText = "You must enter between 1 and 3 tickets"
			inputError();
		}

		else {
			document.querySelector('#msgTickets').innerText = ""
			removeInputError();
		}
	}

	//upon clicking submit, if the inputs are empty, display error
	if (inputName.validity.valueMissing 
	|| inputEmail.validity.valueMissing 
	|| inputTickets.validity.valueMissing) {
		inputError();
	} 

	//if all inputs are filled appropriately, show alert with total
	else {
		alert('Thank you for completing this form.\nYour total will be ' + total + '.')
	}
}