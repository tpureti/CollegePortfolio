
/*
** Thushara Pureti - 11/23/2021
** Utility class that determines whether list object is in ascending order.
** The first checkSorted uses Comparable, using the compareTo method of Polynomial to determine whether strong order is met 
** The second checkSorted uses Comparator, comparing only exponents to determine weak order
** The first checkSorted directly calls the second and displays the results of both tests
*/
import java.util.ArrayList;
import java.util.Comparator;

public class OrderedList {
  static Comparator<Polynomial> comp;

  // checks whether polynomials are in ascending order using compareTo method,
  // then calls second checkSorted method
  public static <T extends Comparable<? super T>> void checkSorted(ArrayList<Polynomial> polynomialList) {
    Polynomial poly1, poly2;
    int listSize = polynomialList.size();
    int comparable[] = new int[listSize - 1];
    int comparator[] = new int[listSize - 1];
    Comparator<Polynomial> weakSort;
    boolean isStrongSorted = true, isWeakSorted = true;
    // for loop that loops through list of polynomials
    for (int i = 0; i < listSize; i++) {
      poly1 = polynomialList.get(i);
      // does not allow last element in list to compare to null element
      if (i < listSize - 1) {
        poly2 = polynomialList.get(i + 1);
        comparable[i] = +poly1.compareTo(poly2);
        // invokes second method which compares by exponents only
        weakSort = checkSorted(polynomialList, comp);
        comparator[i] = +weakSort.compare(poly1, poly2);

        // System.out.println("strong sort results: " + comparable[i]);
        // System.out.println("weak sort results: " + comparator[i]);
      }
    }

    // for loop that checks if strong order is true
    for (int comparison : comparable)
      // if ANY result is greater than -1, set to false and stop
      if (comparison > -1) {
        isStrongSorted = false;
        break;
      }

    // for loop that checks if weak order is true
    for (int comparison : comparator)
      // if ANY result is greater than 0, set to false and stop
      if (comparison > 0) {
        isWeakSorted = false;
        break;
      }

    if (!isStrongSorted && !isWeakSorted)
      System.out.println("This list of polynomials is neither sorted by strong nor weak order.");
    else if (!isStrongSorted && isWeakSorted)
      System.out.println("This list of polynomials is not sorted by strong order but is sorted by weak order.");
    else if (isStrongSorted && !isWeakSorted)
      System.out.println("This list of polynomials is sorted by strong order but not sorted by weak order.");
    else if (isStrongSorted && isWeakSorted)
      System.out.println("This list of polynomials is sorted by both strong and weak order.");
  }

  // checks whether polynomials are ascending purely by their exponents
  public static Comparator<Polynomial> checkSorted(ArrayList<Polynomial> polynomialList, Comparator<Polynomial> comp) {
    comp = new Comparator<Polynomial>() {

      @Override
      public int compare(Polynomial poly1, Polynomial poly2) {
        int first = poly1.front.exponent;
        int second = poly2.front.exponent;
        return first - second;
      }
    };

    return comp;
  }

}
