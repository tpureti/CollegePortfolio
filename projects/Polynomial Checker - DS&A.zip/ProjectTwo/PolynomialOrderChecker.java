import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

/*
** Thushara Pureti - 11/23/2021
** Main method which runs 3 test cases
*/
public class PolynomialOrderChecker {

  public static void main(String[] args) throws IOException {
    // Reads files
    FileReader file1 = new FileReader("PolynomialsUnordered.txt");
    FileReader file2 = new FileReader("PolynomialsWeakOrdered.txt");
    FileReader file3 = new FileReader("PolynomialsOrdered.txt");

    // test 1
    System.out.println("\nTEST 1");
    tests(file1);
    // test 2
    System.out.println("\nTEST 2");
    tests(file2);
    // test 3
    System.out.println("\nTEST 3");
    tests(file3);
  }

  public static void tests(FileReader file) throws IOException {
    // instantiates ArrayList of Polynomial objects
    ArrayList<Polynomial> polynomialList = new ArrayList<Polynomial>();
    // scans file
    Scanner polynomials = new Scanner(file);
    // runs method to populate polynomial list
    polynomialList = scanPolynomials(polynomialList, polynomials);

    // prints the polynomials in correct format
    for (Polynomial poly : polynomialList)
      System.out.println(poly.toString());
    // lambda expression that creates Comparator object for Polynomial objects
    Comparator<Polynomial> byExponent = (poly1, poly2) -> (int) (poly1.front.exponent - poly2.front.exponent);
    // checks Comparator's compare method for weak order
    OrderedList.checkSorted(polynomialList, byExponent);
    // checks custom compareTo method for Polynomial objects for strong order before
    // determining whether requirements for strong/weak order are met
    OrderedList.checkSorted(polynomialList);
  }

  public static ArrayList<Polynomial> scanPolynomials(ArrayList<Polynomial> polynomialList, Scanner polynomials)
      throws IOException {
    double coefficient;
    int exponent;
    Polynomial polynomial = new Polynomial();
    // Scans the file
    // FileReader file = new FileReader("PolynomialsWeakOrdered.txt");
    // polynomials = new Scanner(file);

    // while loop that scans line-by-line
    while (polynomials.hasNextLine()) {
      // sets each line as a string
      String poly = polynomials.nextLine();
      // sets each line as a new Scanner object
      Scanner terms = new Scanner(poly);
      // creates new Polynomial object
      // polynomial = new Polynomial(poly);
      polynomial = new Polynomial();
      polynomial.setPolynomial(poly);
      polynomialList.add(polynomial);

      // scans each line
      while (terms.hasNext()) {
        try {
          coefficient = terms.nextDouble();
          exponent = terms.nextInt();
        } catch (Exception e) {
          throw new InvalidPolynomialSyntax("Missing coefficient or exponent");
        }
        // adds each term to linked list
        polynomial.add(coefficient, exponent);
      }
    }
    return polynomialList;
  }
}
