/*
** Thushara Pureti - 11/23/2021
** Custom exception checker
*/
public class InvalidPolynomialSyntax extends RuntimeException {

  public InvalidPolynomialSyntax() {
    super();
  }

  public InvalidPolynomialSyntax(String message) {
    super(message);
  }
}
