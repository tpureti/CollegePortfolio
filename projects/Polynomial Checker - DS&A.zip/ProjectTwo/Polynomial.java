/*
** Thushara Pureti - 11/23/2021
** Linked list, implements Iterable and Comparable
** 4 methods
*/

import java.util.*;

public class Polynomial implements Iterable<Polynomial.Node>, Comparable<Polynomial> {
  // Polynomial polynomial;
  protected double coefficient; // coefficient (double)
  protected int exponent; // exponent (int)
  String polynomial;
  // references to linked list
  protected Node front;
  protected Node rear;
  protected int numElements = 0;
  protected Node newNode;
  protected String linePoly = "";

  /**
   * Inner class "Node" which holds individual terms (a coefficient + its
   * exponent) of a polynomial in a linked list
   **/
  public static class Node {
    // linked list node attributes
    protected double coefficient; // coefficient (double)
    protected int exponent; // exponent (int)
    public Node newNode;
    protected Node link; // link to next nodeNode
    // references to the list
    protected Node front;
    protected Node rear;
    protected int numElements = 0;
    // set by find method location

    // empty Node constructor
    public Node() {
    }

    // Node constructor
    public Node(double coefficent, int exponent) {
      this.coefficient = coefficent;
      this.exponent = exponent;
      link = null;
    }

    // to string method
    public String toString() {
      if (exponent == 0)
        return coefficient + "";
      else if (exponent == 1)
        return coefficient + "x";
      else if (coefficient == 0)
        return "";
      else
        return coefficient + "x^" + exponent;
    }

    // setter method for info
    public void setInfo(double coefficient, int exponent) {
      this.coefficient = coefficient;
      this.exponent = exponent;
    }

    // getter method for info
    public Node getInfo() {
      Node newNode = new Node(this.coefficient, this.exponent);
      return newNode;
    }

    // getter method for coefficient
    public double getCoefficient() {
      return coefficient;
    }

    // getter method for exponent
    public int getExponent() {
      return exponent;
    }

    // setter method for Polynomial link
    public void setLink(Node link) {
      this.link = link;
    }

    // getter method for Polynomial link
    public Node getLink() {
      return link;
    }
  }

  /**
   * Polynomial class which holds each line (a single polynomial) in an array
   * list.
   */

  // empty default constructor
  public Polynomial() {
    polynomial = null;
  }

  // constructor for Polynomial object
  public Polynomial(String polynomial) {
    this.polynomial = polynomial;
    front = null;
    rear = null;
    numElements = 0;
  }

  // getter method for polynomial object
  public String getPolynomial() {
    return polynomial;
  }

  // setter method for polynomial object
  public void setPolynomial(String polynomial) {
    String regex = "[a-zA-Z]";
    if (polynomial.matches(regex))
      throw new InvalidPolynomialSyntax("Polynomial format not valid");
    else
      this.polynomial = polynomial;
  }

  public boolean add(double coefficient, int exponent) {
    Node newNode = new Node(coefficient, exponent); // creates new node
    if (rear == null || front == null)
      front = newNode; // set newNode to front
    else
      rear.setLink(newNode); // otherwise set rear to new node
    rear = newNode; // sets rear to new node
    numElements++;
    return true;
  }

  // get method which searches by index
  public String get(int index) {
    int i;
    if ((index < 0) || (index >= size()))
      throw new IndexOutOfBoundsException("Illegal index of " + index + " passed to LBList set method.\n");

    newNode = front;
    for (i = 0; i < index; i++)
      newNode = newNode.getLink();
    if (i == 0)
      return newNode.toString();
    else
      return " + " + newNode.toString();
  }

  // method to get size of linked list
  public int size() {
    return numElements;
  }

  // iterator method
  public Iterator<Node> iterator() {

    return new Iterator<Node>() {
      private Node prevPosition = null;
      private Node currentPosition = null;
      private Node nextPosition = front;

      // returns true only if iteration has more elements
      public boolean hasNext() {
        return (nextPosition != null);
      }

      // returns next element in iteration
      public Node next() {
        if (!hasNext())
          throw new IndexOutOfBoundsException();

        Node hold = nextPosition.getInfo();

        currentPosition = nextPosition;
        nextPosition = nextPosition.getLink();
        return hold;
      }
    };
  }

  // Converts the polynomial into a string
  @Override
  public String toString() {
    for (Node terms : this)
      if (terms.coefficient == front.coefficient && terms.exponent == front.exponent)
        linePoly += terms.toString();
      else
        linePoly += " + " + terms.toString();
    return linePoly;
  }

  @Override
  public int compareTo(Polynomial polynomial) {
    Node firstFront = this.front;
    Node secondFront = polynomial.front;
    int comparison = 0;
    Iterator<Node> first = this.iterator();
    Iterator<Node> second = polynomial.iterator();

    // while loop that checks whether polynomial has term
    while (first.hasNext() && second.hasNext()) {
      firstFront = first.next();
      secondFront = second.next();

      // if first polynomial's exponents are greater than second
      if (firstFront.exponent > secondFront.exponent) {
        comparison = 2;
        break;
      }
      // if second polynomial's exponents are greater than first
      else if (firstFront.exponent < secondFront.exponent) {
        comparison = -2;
        break;
      }
      // if polynomial's exponents are equal
      else {
        // if first polynomial's coefficients are greater than second
        if (firstFront.coefficient > secondFront.coefficient) {
          comparison = 1;
          break;
        }
        // if second polynomial's coefficients are great than first
        else if (firstFront.coefficient < secondFront.coefficient) {
          comparison = -1;
          break;
        }
        // if both exponents and coefficients are equal
        else {
          comparison = 0;
        }
      }
    }
    return comparison;
  }
}
