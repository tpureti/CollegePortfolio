/* 1 */ 
INSERT INTO financing_plans (plan_id, institution, loan_type, min_apr, max_apr, min_down, min_loan_amt, max_loan_amt, min_term, max_term) 
VALUES (
'UPPHA',
'Credit Acceptance Corp. (CAC)',
'Used Auto',
2.51,
22.03,
21,
5500,
'125000',
12,
72 );

/* 2 */ 
INSERT INTO financing_plans 
VALUES (
'L2KGH',
'LightStream',
'Used Auto',
5.5,
21.58,
23,
2500,
'100000',
12,
84 );

/* 3 */ 
INSERT INTO financing_plans 
VALUES (
'L1KEL',
'Americredit',
'Used Auto',
7.24,
23.03,
16,
5000,
'125000',
12,
72 );

/* 4 */ 
INSERT INTO financing_plans 
VALUES (
'DYGU6',
'SunTrust',
'Used Auto',
1.52,
8.84,
18,
2500,
'150000',
12,
72 );

/* 5 */ 
INSERT INTO financing_plans 
VALUES (
'6B68V',
'Wells Fargo',
'Used Auto',
2.03,
23.35,
11,
1000,
'80000',
12,
84 );

/* 6 */ 
INSERT INTO financing_plans 
VALUES (
'RN909',
'Affinity Plus',
'Used Auto',
5.67,
8.6,
15,
4500,
'150000',
12,
72 );

/* 7 */ 
INSERT INTO financing_plans 
VALUES (
'4QL2J',
'Credit Acceptance',
'Lease Auto',
2.36,
19.84,
19,
1500,
'80000',
12,
84 );

/* 8 */ 
INSERT INTO financing_plans 
VALUES (
'LOPXQ',
'Gateway One Lending and Finance',
'Used Auto',
7.94,
17.97,
22,
7500,
'100000',
36,
84 );

/* 9 */ 
INSERT INTO financing_plans 
VALUES (
'1FHMJ',
'PNC Bank',
'Used Auto',
1.6,
12.64,
14,
1500,
'100000',
12,
72 );

/* 10 */ 
INSERT INTO financing_plans 
VALUES (
'RU80H',
'ACE Motor Acceptance',
'New Auto',
5.74,
10.12,
14,
5500,
'Undisclosed',
24,
84 );

/* 11 */ 
INSERT INTO financing_plans 
VALUES (
'NESEX',
'Capital One Auto Finance',
'Used Auto',
5.27,
21.84,
13,
1500,
'125000',
36,
72 );

/* 12 */ 
INSERT INTO financing_plans 
VALUES (
'50LQ7',
'Service Finance',
'Used Auto',
2.16,
11.71,
19,
7000,
'80000',
36,
84 );

/* 13 */ 
INSERT INTO financing_plans 
VALUES (
'6Y73V',
'myAutoloan.com',
'Used Auto',
1.02,
25.31,
18,
1000,
'Undisclosed',
24,
84 );

/* 14 */ 
INSERT INTO financing_plans 
VALUES (
'BABVX',
'TD Auto',
'Used Auto',
7.27,
19.96,
23,
3000,
'Undisclosed',
24,
84 );

/* 15 */ 
INSERT INTO financing_plans 
VALUES (
'HOB7D',
'US Bank',
'Used Auto',
3.43,
12.84,
13,
6500,
'150000',
12,
72 );

/* 16 */ 
INSERT INTO financing_plans 
VALUES (
'QCHGX',
'PenFed Credit Union',
'New Auto',
7.37,
11.37,
14,
2000,
'125000',
24,
72 );

/* 17 */ 
INSERT INTO financing_plans 
VALUES (
'J4Z43',
'Carmax',
'Used Auto',
6.15,
23.05,
14,
2000,
'80000',
12,
72 );

/* 18 */ 
INSERT INTO financing_plans 
VALUES (
'TDGXI',
'Consumers Credit Union',
'Used Auto',
7.13,
21.99,
12,
4000,
'125000',
12,
84 );

/* 19 */ 
INSERT INTO financing_plans 
VALUES (
'XU1I5',
'Ally',
'New Auto',
5.45,
24.6,
22,
2500,
'100000',
12,
84 );

/* 20 */ 
INSERT INTO financing_plans 
VALUES (
'EJ2Y4',
'SpringLeaf',
'Used Auto',
7.04,
9.06,
12,
1000,
'125000',
12,
84 );

