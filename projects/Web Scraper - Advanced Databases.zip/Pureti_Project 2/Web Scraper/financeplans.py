from array import array
import random
from unicodedata import decimal
import numpy as np
import string

# initializations
plans_table = []
institution_list = ['Ally', 'Wells Fargo',
                    'ACE Motor Acceptance', 'Capital One Auto Finance', 'US Bank', 'Carmax', 'PenFed Credit Union', 'LightStream', 'Consumers Credit Union', 'myAutoloan.com', 'PNC Bank', 'Affinity Plus', 'Credit Acceptance', 'Americredit', 'TD Auto', 'Gateway One Lending and Finance', 'SunTrust', 'SpringLeaf', 'Service Finance', 'Credit Acceptance Corp. (CAC)']
loan_type_list = ['New Auto', 'Used Auto', 'Lease Auto']
max_loan_list = [80000, 100000, 125000, 150000, 'Undisclosed']
min_term_list = [12, 24, 36]
max_term_list = [72, 84]


def getID():
  # randomize IDs
    chars = string.ascii_uppercase + string.digits
    id = ''.join(random.choice(chars) for i in range(5))
    return id


def getLoanType():
    loan_type = random.choices(loan_type_list, weights=(10, 80, 10))
    return loan_type[0]


def getMinApr():
    # pick min apr
    min_apr_range = np.arange(start=0.99, stop=7.99, step=.01)
    random_min_apr = np.random.choice(a=min_apr_range)
    min_apr = np.round(random_min_apr, 2)
    return min_apr


def getMaxApr():
    # pick max apr
    max_apr_range = np.arange(start=7.99, stop=25.99, step=.01)
    random_max_apr = np.random.choice(a=max_apr_range)
    max_apr = np.round(random_max_apr, 2)
    return max_apr


def getMinDown():
    # pick min down payment
    down_range = np.arange(start=10, stop=25)
    min_down = np.random.choice(a=down_range)
    return min_down


def getMinLoan():
    # pick min loan amount
    min_loan_amt = np.arange(start=500, stop=8000,  step=500)
    min_loan = np.random.choice(a=min_loan_amt)
    return min_loan


def shuffleList():
    random.shuffle(institution_list)
    length = len(institution_list)
    return length


length = shuffleList()


def createTable():
    # create table data
    for i in range(length):
        # get data
        id = getID()
        loan_type = getLoanType()
        min_apr = getMinApr()
        max_apr = getMaxApr()
        min_down = getMinDown()
        min_loan = getMinLoan()
        max_loan = random.choice(max_loan_list)
        min_term = random.choice(min_term_list)
        max_term = random.choice(max_term_list)

        # dictionary of financing plans table
        financing_plans = {
            'id': id,
            'institution': institution_list[i],
            'loan_type': loan_type,
            'min_apr': min_apr,
            'max_apr': max_apr,
            'min_down': min_down,
            'min_loan_amt': min_loan,
            'max_loan_amt': max_loan,
            'min_term': min_term,
            'max_term': max_term
        }

        # make sure ID is unique and add to table
        if (id != financing_plans.values()):
            plans_table.append(financing_plans)


# createTable()


def printList():
    # print list
    for financing_plans in plans_table:
        print()
        print(financing_plans['id'])
        print(financing_plans['institution'])
        print(financing_plans['loan_type'])
        print(financing_plans['min_apr'])
        print(financing_plans['max_apr'])
        print(financing_plans['min_down'])
        print(financing_plans['min_loan_amt'])
        print(financing_plans['max_loan_amt'])
        print(financing_plans['min_term'])
        print(financing_plans['max_term'])


def saveList():
    file = open("list_of_lists.py", "a")
    file.write("\nfinancing_plans = " + str(plans_table) + "\n")


# saveList()


def createSQL():
    # format SQL
    sql_file = open("SQL/FinancingPlansInserts.sql", "w")
    i = 0
    for financing_plans in plans_table:
        # rename
        id = financing_plans['id']
        institution = financing_plans['institution']
        loan_type = financing_plans['loan_type']
        min_apr = financing_plans['min_apr']
        max_apr = financing_plans['max_apr']
        min_down = financing_plans['min_down']
        min_loan = financing_plans['min_loan_amt']
        max_loan = financing_plans['max_loan_amt']
        min_term = financing_plans['min_term']
        max_term = financing_plans['max_term']
        # counter
        i += 1
        if i == 1:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO financing_plans (plan_id, institution, loan_type, min_apr, max_apr, min_down, min_loan_amt, max_loan_amt, min_term, max_term) \n" +
                           "VALUES (\n" +
                           "'" + id + "',\n" +
                           "'" + institution + "',\n" +
                           "'" + loan_type + "',\n" +
                           str(min_apr) + ",\n" +
                           str(max_apr) + ",\n" +
                           str(min_down) + ",\n" +
                           str(min_loan) + ",\n" +
                           "'" + str(max_loan) + "',\n" +
                           str(min_term) + ",\n" +
                           str(max_term) + " );\n\n")
        else:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO financing_plans \n" +
                           "VALUES (\n" +
                           "'" + id + "',\n" +
                           "'" + institution + "',\n" +
                           "'" + loan_type + "',\n" +
                           str(min_apr) + ",\n" +
                           str(max_apr) + ",\n" +
                           str(min_down) + ",\n" +
                           str(min_loan) + ",\n" +
                           "'" + str(max_loan) + "',\n" +
                           str(min_term) + ",\n" +
                           str(max_term) + " );\n\n")


# createSQL()
