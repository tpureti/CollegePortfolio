from array import array
from curses.ascii import FF, isascii
import random
from wsgiref import headers
from bs4 import BeautifulSoup
import requests
import numpy

# links
md = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&n%5B%5D=ar&n%5B%5D=au&n%5B%5D=br&n%5B%5D=celat&n%5B%5D=ch&n%5B%5D=zhtw&n%5B%5D=hr&n%5B%5D=cs&n%5B%5D=dk&n%5B%5D=nl&n%5B%5D=en&n%5B%5D=er&n%5B%5D=fi&n%5B%5D=fr&n%5B%5D=gr&n%5B%5D=gl&n%5B%5D=sp&n%5B%5D=hobbit&n%5B%5D=hu&n%5B%5D=is&n%5B%5D=ig&n%5B%5D=it&n%5B%5D=jpja&n%5B%5D=jp&n%5B%5D=tlh&n%5B%5D=ninja&n%5B%5D=no&n%5B%5D=fa&n%5B%5D=pl&n%5B%5D=ru&n%5B%5D=rucyr&n%5B%5D=gd&n%5B%5D=sl&n%5B%5D=sw&n%5B%5D=th&n%5B%5D=vn&c%5B%5D=us-md&gen=50&age-min=19&age-max=80"
dc = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&n%5B%5D=ar&n%5B%5D=au&n%5B%5D=br&n%5B%5D=celat&n%5B%5D=ch&n%5B%5D=zhtw&n%5B%5D=hr&n%5B%5D=cs&n%5B%5D=dk&n%5B%5D=nl&n%5B%5D=en&n%5B%5D=er&n%5B%5D=fi&n%5B%5D=fr&n%5B%5D=gr&n%5B%5D=gl&n%5B%5D=sp&n%5B%5D=hobbit&n%5B%5D=hu&n%5B%5D=is&n%5B%5D=ig&n%5B%5D=it&n%5B%5D=jpja&n%5B%5D=jp&n%5B%5D=tlh&n%5B%5D=ninja&n%5B%5D=no&n%5B%5D=fa&n%5B%5D=pl&n%5B%5D=ru&n%5B%5D=rucyr&n%5B%5D=gd&n%5B%5D=sl&n%5B%5D=sw&n%5B%5D=th&n%5B%5D=vn&c%5B%5D=us-dc&gen=50&age-min=19&age-max=80"
va = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&n%5B%5D=ar&n%5B%5D=au&n%5B%5D=br&n%5B%5D=celat&n%5B%5D=ch&n%5B%5D=zhtw&n%5B%5D=hr&n%5B%5D=cs&n%5B%5D=dk&n%5B%5D=nl&n%5B%5D=en&n%5B%5D=er&n%5B%5D=fi&n%5B%5D=fr&n%5B%5D=gr&n%5B%5D=gl&n%5B%5D=sp&n%5B%5D=hobbit&n%5B%5D=hu&n%5B%5D=is&n%5B%5D=ig&n%5B%5D=it&n%5B%5D=jpja&n%5B%5D=jp&n%5B%5D=tlh&n%5B%5D=ninja&n%5B%5D=no&n%5B%5D=fa&n%5B%5D=pl&n%5B%5D=ru&n%5B%5D=rucyr&n%5B%5D=gd&n%5B%5D=sl&n%5B%5D=sw&n%5B%5D=th&n%5B%5D=vn&c%5B%5D=us-va&gen=50&age-min=19&age-max=80"

# headers
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) Brave/1.32.113 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36',
    'Referer': 'https://www.fakenamegenerator.com/'
}

# list of states
states = [md, dc, va]

# initialize empty list of customers
customers_table = []

for i in range(200):
    # randomize state selection
    random_state = random.choice(states)
    page = requests.get(random_state, allow_redirects=True,
                        headers=headers, timeout=500)

    # parse info from html
    soup = BeautifulSoup(page.content, "html.parser")
    information = soup.find("div", class_="address")
    # name
    name_html = information.find("h3")
    name = name_html.text.replace("'", "''")
    fullname = name.split()
    # full address html
    address_html = information.find("div", class_="adr")
    # split address html into two lines
    split_address_html = address_html.find("br")
    split_address_html.replace_with('\n')
    full_address = address_html.text.strip()
    split_address = full_address.split("\n")

    # name attributes
    if len(fullname) == 3:
        fname = fullname[0]
        mname = fullname[1]
        mi = mname[0]
        lname = fullname[2]
    elif len(fullname) == 2:
        fname = fullname[0]
        mi = ""
        lname = fullname[1]
    else:
        fname = fullname[0]
        mi = ""
        lname = fullname[0]

    # address attributes
    street = split_address[0]
    citystatezip = split_address[1]
    split_address2 = citystatezip.split(",")
    city = split_address2[0]
    statezip = split_address2[1].split()
    state = statezip[0]
    zip = statezip[1]

    # random id creator
    id_range = numpy.arange(start=273344, stop=287463)
    random_id = numpy.random.choice(a=id_range, replace=False)
    id = str(random_id)

    # customer dictionary
    customer = {
        'id': id,
        'fname': fname,
        'lname': lname,
        'mi': mi,
        'street': street,
        'city': city,
        'state': state,
        'zip': zip
    }

    # method that checks whether name uses ASCII letters
    def isEnglish(fullname):
        return fullname[0].isascii()

    fullname[0].encode()

    # add customers to list
    if isEnglish(fullname) == True & (fname != lname):
        customers_table.append(customer)

# access customers
for customer in customers_table:
    print("ID: " + customer['id'])
    print("Name: " + customer['fname'] + " " +
          customer['mi'] + " " + customer['lname'])
    print("Steet: " + customer['street'])
    print("City: " + customer['city'])
    print("State: " + customer['state'])
    print("Zip Code: " + customer['zip'])
    print()

file = open("list_of_lists.py", "a")
file.write("\ncustomers = " + str(customers_table) + "\n")

# format SQL
sql_file = open("SQL/CustomerInserts.sql", "w")

n = 0
# loop through customers list and format into SQL
for customer in customers_table:
    n += 1
    if n == 1:
        sql_file.write("/* " + str(n) + " */ \n" +
                       "INSERT INTO customers (sale_id, VIN, customer_id, salesperson_id, vehicle_status, sale_date, mileage, sale_price) \n" +
                       "VALUES (\n" +
                       "'" + customer['id'] + "',\n" +
                       "'" + customer['fname'] + "',\n" +
                       "'" + customer['lname'] + "',\n" +
                       "'" + customer['mi'] + "',\n" +
                       "'" + customer['street'] + "',\n" +
                       "'" + customer['city'] + "',\n" +
                       "'" + customer['state'] + "',\n" +
                       customer['zip'] + " );\n\n")
    else:
        sql_file.write("/* " + str(n) + " */ \n" +
                       "INSERT INTO customers \n" +
                       "VALUES (\n" +
                       "'" + customer['id'] + "',\n" +
                       "'" + customer['fname'] + "',\n" +
                       "'" + customer['lname'] + "',\n" +
                       "'" + customer['mi'] + "',\n" +
                       "'" + customer['street'] + "',\n" +
                       "'" + customer['city'] + "',\n" +
                       "'" + customer['state'] + "',\n" +
                       customer['zip'] + " );\n\n")
