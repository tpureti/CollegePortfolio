# others
import random
import datetime

import numpy
# mine
from list_of_lists import salespeople, vehicles, customers

sales_table = []


def getID(i):
    id = 'SL-' + str(i + 1)
    return id


def getVehicleInfo():
    vehicle_list = random.choice(vehicles)
    vehicle_id = vehicle_list['id']
    sale_price = vehicle_list['retail_cost']
    dealer_id = vehicle_list['dealer_id']
    tradein = vehicle_list['trade_in']
    year = vehicle_list['year']
    if tradein == 'Y':
        status = 'USED'
    elif tradein == 'N':
        status = 'NEW'
    return vehicle_id, sale_price, dealer_id, status, year


def getCustomerID():
    customer_list = random.choice(customers)
    customer_id = customer_list['id']
    return customer_id


def getSalespersonID(dealer_id):
    salesperson_list = []
    for salesperson in salespeople:
        if dealer_id in salesperson['dealer_id']:
            salesperson_list.append(salesperson)

            salesperson = random.choice(salesperson_list)
            salesperson_id = salesperson['id']
            return salesperson_id


def getMileage(year):
    years = 2022 - int(year)
    for i in range(years):
        mi_range = numpy.arange(start=5000, stop=25000)
        mpy = numpy.random.choice(mi_range)
    mileage = + mpy
    return mileage


def getSaleDate():
    start = datetime.date(2020, 1, 1)
    end = datetime.date.today()
    dates = end - start
    rand_days = random.randint(0, dates.days)
    random_date = start + datetime.timedelta(days=rand_days)
    date = random_date.strftime("%y-%b-%d")
    return date


def createTable():
    for i in range(300):
        # get info
        sale_id = getID(i)
        vehicle_id, sale_price, dealer_id, status, year = getVehicleInfo()
        customer_id = getCustomerID()
        salesperson_id = getSalespersonID(dealer_id)
        mileage = getMileage(year)
        sale_date = getSaleDate()
        # dictionary
        sale = {
            'sale_id': sale_id,
            'vehicle_id': vehicle_id,
            'customer_id': customer_id,
            'salesperson_id': salesperson_id,
            'vehicle_status': status,
            'sale_price': sale_price,
            'mileage': mileage,
            'sale_date': sale_date
        }

        sales_table.append(sale)


createTable()


def printList():
    for sales in sales_table:
        print()
        print(sales['sale_id'])
        print(sales['vehicle_id'])
        print(sales['customer_id'])
        print(sales['salesperson_id'])
        print(sales['vehicle_status'])
        print(sales['sale_price'])
        print(sales['mileage'])
        print(sales['sale_date'])


# printList()


def saveList():
    file = open("list_of_lists.py", "a")
    file.write("\nsales = " + str(sales_table) + "\n")


# saveList()


def createSQL():
    sql_file = open("SQL/SalesInserts.sql", "w")
    i = 0
    for sales in sales_table:
        # rename
        sale_id = sales['sale_id']
        vehicle_id = sales['vehicle_id']
        customer_id = sales['customer_id']
        salesperson_id = sales['salesperson_id']
        status = sales['vehicle_status']
        sale_price = sales['sale_price']
        mileage = sales['mileage']
        sale_date = sales['sale_date']
        # counter
        i += 1
        if i == 1:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO sales (sale_id, vehicle_id, customer_id, salesperson_id, vehicle_status, sale_price, mileage, sale_date) \n" +
                           "VALUES (\n" +
                           "'" + sale_id + "',\n" +
                           "'" + vehicle_id + "',\n" +
                           "'" + customer_id + "',\n" +
                           "'" + salesperson_id + "',\n" +
                           "'" + status + "',\n" +
                           str(sale_price) + ",\n" +
                           str(mileage) + ",\n" +
                           "'" + sale_date + "' );\n\n")
        else:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO sales \n" +
                           "VALUES (\n" +
                           "'" + sale_id + "',\n" +
                           "'" + vehicle_id + "',\n" +
                           "'" + customer_id + "',\n" +
                           "'" + salesperson_id + "',\n" +
                           "'" + status + "',\n" +
                           str(sale_price) + ",\n" +
                           str(mileage) + ",\n" +
                           "'" + sale_date + "' );\n\n")


# createSQL()
