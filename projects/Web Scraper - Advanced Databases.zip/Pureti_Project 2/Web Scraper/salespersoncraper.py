from array import array
from curses.ascii import FF, isascii
import datetime
import random
from time import time
from wsgiref import headers
from bs4 import BeautifulSoup
import requests
import numpy
import string
import time

# links
md = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&c%5B%5D=us-md&gen=50&age-min=19&age-max=80"
dc = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&c%5B%5D=us-dc&gen=50&age-min=19&age-max=80"
va = "https://www.fakenamegenerator.com/advanced.php?t=region&n%5B%5D=us&c%5B%5D=us-va&gen=50&age-min=19&age-max=80"

# headers
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) Brave/1.32.113 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36',
    'Referer': 'https://www.fakenamegenerator.com/'
}

# list of states
states = [md, dc, va]

# initializations
salespersons_table = []
dealer_list = []
hire_date = []


def getName():
  # scrape name
  # randomize state selection
    random_state = random.choice(states)
    page = requests.get(random_state, allow_redirects=True,
                        headers=headers)

    # parse info from html
    soup = BeautifulSoup(page.content, "html.parser")
    information = soup.find("div", class_="address")
    # name
    name_html = information.find("h3")
    name = name_html.text.replace("'", "''")
    fullname = name.split()
    fname = fullname[0]
    mname = fullname[1]
    mi = mname[0]
    lname = fullname[2]
    return fname, mi, lname


def getID():
    id_range = numpy.arange(start=000, stop=999)
    random_id = numpy.random.choice(a=id_range, replace=False)
    id = 'SP' + str(random_id)
    return id


def getDealerID():
  # generate random dealer ID
    chars = ''.join(random.choice(string.ascii_uppercase) for i in range(3))
    numbers = ''.join(random.choice(string.digits) for i in range(4))
    dealer_id = '-'.join([chars, numbers])
    return dealer_id


# add 10 dealership entries
def createDealerList():
    for i in range(10):
        dealer_list.append(getDealerID())
    return dealer_list


def getRandomDate():
  # generate random hire date
    start = datetime.date(2000, 1, 1)
    end = datetime.date(2022, 1, 1)
    dates = end - start
    rand_days = random.randint(0, dates.days)
    random_date = start + datetime.timedelta(days=rand_days)
    date = random_date.strftime("%y-%b-%d")
    return date


def createTable():
    # create table of salespersons
    for i in range(30):
        # get data
        fname, mi, lname = getName()
        id = getID()
        dealer_list = createDealerList()
        dealer_id = random.choice(dealer_list)
        hire_date = getRandomDate()

        # employee dictionary
        salesperson = {
            'id': id,
            'fname': fname,
            'lname': lname,
            'mi': mi,
            'dealer_id': dealer_id,
            'hire_date': hire_date
        }
        # # make sure ID is unique and add to table
        # if (id != salespersons_table.values()):
        salespersons_table.append(salesperson)


def printList():
    # print list
    for salesperson in salespersons_table:
        print()
        print(salesperson['id'])
        print(salesperson['fname'])
        print(salesperson['lname'])
        print(salesperson['mi'])
        print(salesperson['dealer_id'])
        print(salesperson['hire_date'])


def saveList():
    file = open("list_of_lists.py", "a")
    file.write("salespeople = " + str(salespersons_table) + "\n")


def createSQL():
    # format SQL
    sql_file = open("SQL/SalespersonInserts.sql", "w")

    i = 0
    for salesperson in salespersons_table:
        i += 1
        if i == 1:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO salespersons (salesperson_id, first_name, last_name, MI, dealer_id, hire_date) \n" +
                           "VALUES (\n" +
                           "'" + salesperson['id'] + "',\n" +
                           "'" + salesperson['fname'] + "',\n" +
                           "'" + salesperson['lname'] + "',\n" +
                           "'" + salesperson['mi'] + "',\n" +
                           "'" + salesperson['dealer_id'] + "',\n" +
                           "'" + salesperson['hire_date'] + "' );\n\n")
        else:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO salespersons \n" +
                           "VALUES (\n" +
                           "'" + salesperson['id'] + "',\n" +
                           "'" + salesperson['fname'] + "',\n" +
                           "'" + salesperson['lname'] + "',\n" +
                           "'" + salesperson['mi'] + "',\n" +
                           "'" + salesperson['dealer_id'] + "',\n" +
                           "'" + salesperson['hire_date'] + "' );\n\n")


createSQL()
