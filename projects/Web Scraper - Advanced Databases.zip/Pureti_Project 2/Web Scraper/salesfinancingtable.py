import math
import random
import numpy
from list_of_lists import sales, financing_plans

sales_financing_table = []
sale_id = []
plan_id = []
apr = []
down_pay = []
loan_term = []


def getPlan(sale):
    plan_list = []
    if 'USED' in sale['vehicle_status']:
        for plan in financing_plans:
            if 'Used Auto' in plan['loan_type']:
                plan_list.append(plan)

    elif 'NEW' in sale['vehicle_status']:
        for plan in financing_plans:
            if 'Used Auto' not in plan['loan_type']:
                plan_list.append(plan)

    # randomly choose and print
    loan_type = random.choice(plan_list)
    return loan_type


def getPlanID(plan):
    id = plan['id']
    return id


def getAPR(plan):
    min_apr = plan['min_apr']
    max_apr = plan['max_apr']
    apr_range = numpy.arange(start=min_apr, stop=max_apr, step=.01)
    random_apr = numpy.random.choice(apr_range)
    apr = numpy.round(random_apr, 2)
    return apr


def getDownPay(plan, price):
    down = (plan['min_down'] * int(price)) * .01
    down_pay = numpy.round(down, 2)
    return down_pay


def getLoanTerm(plan):
    min_term = plan['min_term']
    max_term = plan['max_term']
    term_range = numpy.arange(start=min_term, stop=max_term, step=12)
    term = random.choice(term_range)
    return term


def createTable():
    for sale in sales:
        # get info
        sale_id = sale['sale_id']
        price = sale['sale_price']
        plan = getPlan(sale)
        plan_id = getPlanID(plan)
        apr = getAPR(plan)
        down_pay = getDownPay(plan, price)
        loan_term = getLoanTerm(plan)
        # dictionary
        sales_financing = {
            'sale_id': sale_id,
            'plan_id': plan_id,
            'apr': apr,
            'down_pay': down_pay,
            'loan_term': loan_term
        }

        sales_financing_table.append(sales_financing)


createTable()


def printList():
    for sales_financing in sales_financing_table:
        print()
        print(sales_financing['sale_id'])
        print(sales_financing['plan_id'])
        print(sales_financing['apr'])
        print(sales_financing['down_pay'])
        print(sales_financing['loan_term'])


# printList()


def saveList():
    file = open("list_of_lists.py", "a")
    file.write("\nsales_financing = " + str(sales_financing_table) + "\n")


# saveList()


def createSQL():
    sql_file = open("SQL/SalesFinancingInserts.sql", "w")
    i = 0
    for sales_financing in sales_financing_table:
        i += 1
        if i == 1:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO sales_financings (sale_id, plan_id, apr, down_payment,loan_term) \n" +
                           "VALUES (\n" +
                           "'" + sales_financing['sale_id'] + "',\n" +
                           "'" + sales_financing['plan_id'] + "',\n" +
                           str(sales_financing['apr']) + ",\n" +
                           str(sales_financing['down_pay']) + ",\n" +
                           str(sales_financing['loan_term']) + " );\n\n")
        else:
            sql_file.write("/* " + str(i) + " */ \n" +
                           "INSERT INTO sales_financings \n" +
                           "VALUES (\n" +
                           "'" + sales_financing['sale_id'] + "',\n" +
                           "'" + sales_financing['plan_id'] + "',\n" +
                           str(sales_financing['apr']) + ",\n" +
                           str(sales_financing['down_pay']) + ",\n" +
                           str(sales_financing['loan_term']) + " );\n\n")


# createSQL()
