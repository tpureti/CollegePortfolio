# web scraping
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
# others
import random
import string
import json
import requests
# mine
from car_list import car_list
from list_of_lists import salespeople, vehicles

# initializations
older_cars_list = []
vehicles_table = []


def callAPI():
    # return API in json format
    API = 'https://parseapi.back4app.com/classes/Carmodels_Car_Model_List?limit=1'
    headers = {
        # This is your app's application id
        'X-Parse-Application-Id': 'PIxM6PekTB8XVetuIWiozE6aDkXyX6u5lAoqfBBP',
        # This is your app's REST API key
        'X-Parse-REST-API-Key': 'ixcWPzbGAxyI5rNpUUNzEyboPVUkR7bHXUdS0lWc'
    }
    # parse json
    json_data = json.loads(requests.get(
        API, headers=headers).content.decode('utf-8'))
    data = json_data['results']
    return data


def parseJSON(data):
    # add to dictionary
    for i in data:
        cars = dict()
        year = i['Year']
        cars['Make'] = i['Make']
        cars['Model'] = i['Model']
        cars['Type'] = i['Category']
        cars['Year'] = year
        # add to list
        if year > 2020:
            car_list.append(cars)
        elif year > 1998 & year < 2015:
            older_cars_list.append(cars)


def shuffleLists():
    # shuffle lists
    random.shuffle(older_cars_list)
    older_cars = random.choices(older_cars_list, k=500)
    car_list.append(older_cars)


def getID():
    chars = string.ascii_uppercase
    char = random.choice(chars)
    num = string.digits
    id = ''.join(random.choice(chars) for i in range(2))
    num = ''.join(random.choice(num) for i in range(5))
    car_id = id + num + char
    return car_id


def getBasicCarData():
    # get basic info from json
    car_info = random.choices(car_list)
    info = car_info[0]
    make = info['Make']
    model = info['Model']
    type = info['Type']
    year = info['Year']
    return make, model, type, year


def searchGoogle():
    # search google
    make, model, type, year = getBasicCarData()
    # choose random type
    type = type.split(',')
    type = random.choice(type)
    type = str(type).strip()

    url = 'https://www.google.com/search?q=' + \
        str(year) + "+" + make + "+" + model + "+"
    if year >= 2021:
        url = url + "invoice+%3Aedmunds"
    else:
        url = url + "appraisal-value+%3Aedmunds"
    return url, make, model, type, year


def setUpSelenium():
    # setting up selenium
    s = Service('/usr/local/chrome/chromedriver')
    options = Options()
    options.headless = True
    options.add_argument('user-agent=[user-agent string]')
    driver = webdriver.Chrome(service=s, options=options)
    return driver


def getNewCarPrices(entry):
    price = str(entry).replace(
        '<td class="p-1 px-md-1_5 align-middle text-center">', '').replace('</td>', '').replace('$', '').replace(',', '')
    return price


def getGoogleLink(soup):
    # get first link from google
    html = soup.find('div', class_='egMi0 kCrYT')
    link_html = html.find('a', href=True)
    actual_link = link_html['href']
    link = actual_link.replace('/url?q=', '')
    real_link = link.rsplit('&sa=')
    edmunds_link = real_link[0]
    return edmunds_link


def getCarPrices():
    # get car prices from scraping
    url, make, model, type, year = searchGoogle()
    # set up selenium
    driver = setUpSelenium()
    # request google url
    driver.get(url)
    soup = BeautifulSoup(driver.page_source, "html.parser")
    # request edmunds link
    link = getGoogleLink(soup)
    print(link)
    driver.get(link)
    # parse all html
    soup = BeautifulSoup(driver.page_source, "html.parser")

    # invoice prices
    if year >= 2021:
        trade_in = 'N'  # set trade in values to FALSE
        # get basic car model name
        car_html = soup.find('h1', class_='heading-2 mb-2')
        car_name = car_html.text.split(make)
        car_model = car_name[1].split('MSRP and Invoice Price')
        model = car_model[0].strip()
        # table
        table = soup.find('table').find_all('tr')
        # full list
        invoices_prices_list = []
        for row in table[1:]:
            trims_invoice_retail = dict()
            i = 0
            for entry in row:
                i += 1
                # trims
                if i == 1:
                    trim = str(entry).replace(
                        '<td class="p-1 px-md-1_5 align-middle font-weight-bold pos-r">', '').replace('<!-- --> </td>', '').replace('<!-- --> <span class="most-popular-label size-10 ml-0_5 font-weight-bold text-primary-darker align-middle">Most Popular</span></td>', '')
                    trims_invoice_retail['trim'] = trim
                # msrp prices
                if i == 2:
                    msrp = getNewCarPrices(entry)
                    trims_invoice_retail['msrp'] = msrp
                # invoice prices
                elif i == 3:
                    invoice = getNewCarPrices(entry)
                    trims_invoice_retail['invoice'] = invoice
                # retail prices
                elif i == 4:
                    retail = getNewCarPrices(entry)
                    trims_invoice_retail['retail'] = retail

            invoices_prices_list.append(trims_invoice_retail)

        rand = random.choice(invoices_prices_list)
        trim = rand['trim']
        msrp = rand['msrp']
        invoice = rand['invoice']
        retail = rand['retail']
        # get price
        if invoice == 'N/A':
            price = msrp
        else:
            price = invoice

    # trade in prices
    else:
        trade_in = 'Y'  # set trade in values to TRUE
        # get basic car model name
        car_html = soup.find('div', class_='heading-3 mb-0_25')
        car_name = car_html.text.split('Estimated values for the ')
        car_model = car_name[1].split(make)
        # rename model
        model = car_model[1].strip()
        # tables
        tables = soup.find(
            'div', class_='estimated-values-container').find_all('table')

        # full list
        tradein_prices_list = []
        for info in tables:
            # dictionary
            trims_tradein = dict()
            # parse trims
            trims = info.find_all('caption')
            trim = str(trims).replace(
                '[<caption class="text-gray-darker size-16 mb-0_25">', '').replace('<!-- --> with no options</caption>]', '').split('(')
            tri = trim[0]
            if '4dr' in tri:
                trim = tri.split('4dr')
            if '3dr' in tri:
                trim = tri.split('3dr')
            elif '2dr' in tri:
                trim = tri.split('2dr')
            # add trim
            if str(trim).strip() == '':
                trims_tradein['trim'] = trim[1].strip()
            else:
                trims_tradein['trim'] = trim[0].strip()

            # body = info.find('tbody')
            table = info.find_all('tr')

            price_list = []
            for row in table[1:]:
                i = 0
                used_prices = dict()
                for cell in row:
                    i += 1
                    if i == 1:
                        condition = str(cell).replace(
                            '<th class="text-capitalize font-weight-normal" scope="row">', '').replace('</th>', '')
                        used_prices['condition'] = condition
                    if i == 2:
                        trade = str(cell).replace(
                            '<td class="text-right">', '').replace('</td>', '').replace(',', '').replace('$', '')
                        used_prices['trade_in'] = trade
                    if i == 4:
                        retail = trade = str(cell).replace(
                            '<td class="text-right">', '').replace('</td>', '').replace(',', '').replace('$', '')
                        used_prices['retail'] = retail
                    price_list.append(used_prices)
                trims_tradein['prices'] = price_list
                # add to list
            tradein_prices_list.append(trims_tradein)

        # get random trim and price
        rand = random.choice(tradein_prices_list)
        trim = rand['trim']
        rand_price = rand['prices']
        condition = random.choice(rand_price)
        price = condition['trade_in']
        retail = condition['retail']

    driver.quit()
    # return tuples
    return year, type, make, model, trim, price, trade_in, retail


def createTable():
    for i in range(100):
        print(str(i))
        # get data
        id = getID()
        year, type, make, model, trim, price, trade_in, retail = getCarPrices()
        dealer_list = random.choice(salespeople)
        dealer_id = dealer_list['dealer_id']

        # dictionary
        car = {
            'id': id,
            'year': str(year),
            'make': make,
            'model': model,
            'trim': trim,
            'type': type,
            'wholesale_cost': str(price),
            'retail_cost': retail,
            'trade_in': trade_in,
            'dealer_id': dealer_id
        }

        vehicles_table.append(car)
    return vehicles_table


# run loop until I get enough cars
# for i in range(5):
#     try:
#         createTable()
#     except:
#         print("error")
#         continue
#     break


def printList():
    print(len(vehicles_table))
    for car in vehicles_table:
        print()
    print("ID: " + car['id'])
    print("Year: " + car['year'])
    print("Make: " + car['make'])
    print("Model: " + car['model'])
    print("Trim: " + car['trim'])
    print("Type: " + car['type'])
    print("Cost: $" + car['wholesale_cost'])
    print("Retail: $" + car['retail_cost'])
    print("Trade-in: " + car['trade_in'])
    print("Dealer: " + car['dealer_id'])


# printList()


def saveList():
    file = open("list_of_lists.py", "a")
    file.write("\nvehicles = " + str(vehicles_table) + "\n")


# saveList()


def createSQL():
    # format SQL
    sql_file = open("SQL/CarInserts.sql", "w")
    i = 0
    for car in vehicles:
        # attributes
        id = car['id']
        year = car['year']
        make = car['make']
        model = car['model']
        trim = car['trim']
        type = car['type']
        cost = car['wholesale_cost']
        tradein = car['trade_in']
        dealer = car['dealer_id']

        i += 1
        if i == 1:
            sql_file.write("/* " + str(i) + " */ \n"
                           "INSERT INTO vehicles (vehicle_id, year, make, model, trim, type, wholesale_cost, dealer_id) \n" +
                           "VALUES (\n" +
                           "'" + id + "',\n" +
                           year + ",\n" +
                           "'" + make + "',\n" +
                           "'" + model + "',\n" +
                           "'" + trim + "',\n" +
                           "'" + type + "',\n" +
                           cost + ",\n" +
                           "'" + tradein + "',\n" +
                           "'" + dealer + "' );\n\n")
        else:
            sql_file.write("/* " + str(i) + " */ \n"
                           "INSERT INTO vehicles \n" +
                           "VALUES (\n" +
                           "'" + id + "',\n" +
                           year + ",\n" +
                           "'" + make + "',\n" +
                           "'" + model + "',\n" +
                           "'" + trim + "',\n" +
                           "'" + type + "',\n" +
                           cost + ",\n" +
                           "'" + tradein + "',\n" +
                           "'" + dealer + "' );\n\n")


createSQL()
