--------------------------------------------------------
-- Create table for CUSTOMERS
--------------------------------------------------------
CREATE TABLE customers (
    customer_id char(6) -- primary key --
    CONSTRAINT PK_customer_id PRIMARY KEY,
    first_name varchar(255) NOT NULL,
    last_name varchar(255) NOT NULL,
    MI char(1),
    street varchar(255) NOT NULL,
    city varchar(255) NOT NULL,
    state char(2) NOT NULL,
    zip_code char(5) NOT NULL,
    ----------------------------------------------------
    -- CHECKS
    ----------------------------------------------------
    CONSTRAINT CHK_customer_id CHECK (REGEXP_LIKE(customer_id, '^[[:digit:]]{6}$')),
    CONSTRAINT CHK_customer_zip CHECK (REGEXP_LIKE(zip_code, '^[[:digit:]]{5}$'))
);

--------------------------------------------------------
-- Create table for VEHICLES
--------------------------------------------------------
CREATE TABLE vehicles (
    vehicle_id varchar(8) -- primary key --
    CONSTRAINT PK_vehicle_id PRIMARY KEY,
    year char(4) NOT NULL,
    make varchar(50) NOT NULL,
    model varchar(50) NOT NULL,
    trim varchar(255), -- to distinguish between models --
    type varchar(50) NOT NULL,
    wholesale_cost int NOT NULL,
    tradein char(1) NOT NULL, -- boolean check if it's a trade in or not --
    dealer_id varchar(8) NOT NULL,
    ----------------------------------------------------
    -- CHECKS
    ----------------------------------------------------
    CONSTRAINT CHK_tradein CHECK (tradein IN ('Y', 'N')),
    CONSTRAINT CHK_vehicle_year CHECK (REGEXP_LIKE(year, '^[[:digit:]]{4}$'))
);

--------------------------------------------------------
-- Create table for SALESPERSONS
--------------------------------------------------------
CREATE TABLE salespersons (
    salesperson_id char(5)
    CONSTRAINT PK_salesperson_id PRIMARY KEY,
    first_name varchar(255) NOT NULL,
    last_name varchar(255) NOT NULL,
    MI char(1),
    dealer_id varchar(8) NOT NULL,
    hire_date date NOT NULL
);

--------------------------------------------------------
-- Create table for SALES
--------------------------------------------------------
CREATE TABLE sales (
    sale_id varchar(10) -- primary key --
    CONSTRAINT PK_sale_id PRIMARY KEY,
    vehicle_id varchar(17) NOT NULL,
    customer_id char(6) NOT NULL,
    salesperson_id char(5) NOT NULL,
    vehicle_status varchar(50) NOT NULL,
    sale_price int NOT NULL,
    mileage int NOT NULL,
    sale_date date NOT NULL,
    ----------------------------------------------------
    -- FOREIGN KEYS
    ----------------------------------------------------
    CONSTRAINT FK_sales_vehicle_id FOREIGN KEY (vehicle_id) 
    REFERENCES vehicles (vehicle_id),
    CONSTRAINT FK_sales_customer_id FOREIGN KEY (customer_id)
    REFERENCES customers (customer_id),
    CONSTRAINT FK_sales_salesperson_id FOREIGN KEY (salesperson_id)
    REFERENCES salespersons (salesperson_id),
    ----------------------------------------------------
    -- CHECKS
    ----------------------------------------------------
    CONSTRAINT CHK_vehicle_status CHECK (vehicle_status IN ('NEW', 'USED'))
);

--------------------------------------------------------
-- Create table for FINANCING PLANS
--------------------------------------------------------
CREATE TABLE financing_plans (
    plan_id char(5) -- primary key --
    CONSTRAINT PK_plan_id PRIMARY KEY,
    institution varchar(50) NOT NULL,
    loan_type varchar(50),
    min_apr decimal(9, 2) NOT NULL,
    max_apr decimal(9, 2) NOT NULL,
    min_down decimal (6,1) NOT NULL,
    min_loan_amt varchar(20) NOT NULL,
    max_loan_amt varchar(20) NOT NULL,
    min_term int NOT NULL,
    max_term int NOT NULL,
    ----------------------------------------------------
    -- CHECKS
    ----------------------------------------------------
    CONSTRAINT CHK_loan_type CHECK (loan_type IN ('New Auto', 'Used Auto', 'Lease Auto'))
);

--------------------------------------------------------
-- Create table for SALES FINANCING
--------------------------------------------------------
CREATE TABLE sales_financings (
    sale_id varchar(10) NOT NULL,
    plan_id char(5) NOT NULL,
    apr decimal(9, 2) NOT NULL,
    down_payment int NOT NULL,
    loan_term int NOT NULL,
    ----------------------------------------------------
    -- FOREIGN KEYS
    ----------------------------------------------------
    CONSTRAINT PK_financing_sale_id FOREIGN KEY (sale_id)
    REFERENCES sales (sale_id),
    CONSTRAINT PK_financing_plan_id FOREIGN KEY (plan_id)
    REFERENCES financing_plans (plan_id)
);