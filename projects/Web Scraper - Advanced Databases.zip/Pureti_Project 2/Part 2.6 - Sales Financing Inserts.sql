/* 1 */ 
INSERT INTO sales_financings (sale_id, plan_id, apr, down_payment,loan_term) 
VALUES (
'SL-1',
'J4Z43',
21.68,
8961.26,
48 );

/* 2 */ 
INSERT INTO sales_financings 
VALUES (
'SL-2',
'6Y73V',
21.92,
3679.56,
24 );

/* 3 */ 
INSERT INTO sales_financings 
VALUES (
'SL-3',
'EJ2Y4',
8.51,
929.52,
60 );

/* 4 */ 
INSERT INTO sales_financings 
VALUES (
'SL-4',
'UPPHA',
5.29,
13300.56,
48 );

/* 5 */ 
INSERT INTO sales_financings 
VALUES (
'SL-5',
'UPPHA',
20.95,
8287.86,
12 );

/* 6 */ 
INSERT INTO sales_financings 
VALUES (
'SL-6',
'TDGXI',
8.91,
415.44,
48 );

/* 7 */ 
INSERT INTO sales_financings 
VALUES (
'SL-7',
'4QL2J',
12.13,
4459.68,
12 );

/* 8 */ 
INSERT INTO sales_financings 
VALUES (
'SL-8',
'BABVX',
7.57,
6741.99,
24 );

/* 9 */ 
INSERT INTO sales_financings 
VALUES (
'SL-9',
'6Y73V',
5.05,
6233.58,
60 );

/* 10 */ 
INSERT INTO sales_financings 
VALUES (
'SL-10',
'TDGXI',
16.78,
520.08,
48 );

/* 11 */ 
INSERT INTO sales_financings 
VALUES (
'SL-11',
'NESEX',
21.51,
19144.32,
48 );

/* 12 */ 
INSERT INTO sales_financings 
VALUES (
'SL-12',
'LOPXQ',
15.31,
9659.32,
36 );

/* 13 */ 
INSERT INTO sales_financings 
VALUES (
'SL-13',
'NESEX',
6.35,
5078.19,
48 );

/* 14 */ 
INSERT INTO sales_financings 
VALUES (
'SL-14',
'L2KGH',
18.52,
8877.77,
48 );

/* 15 */ 
INSERT INTO sales_financings 
VALUES (
'SL-15',
'EJ2Y4',
8.53,
4449.0,
72 );

/* 16 */ 
INSERT INTO sales_financings 
VALUES (
'SL-16',
'HOB7D',
7.86,
6193.33,
12 );

/* 17 */ 
INSERT INTO sales_financings 
VALUES (
'SL-17',
'UPPHA',
12.14,
1404.27,
12 );

/* 18 */ 
INSERT INTO sales_financings 
VALUES (
'SL-18',
'L1KEL',
18.85,
6314.56,
48 );

/* 19 */ 
INSERT INTO sales_financings 
VALUES (
'SL-19',
'RN909',
7.2,
7146.15,
36 );

/* 20 */ 
INSERT INTO sales_financings 
VALUES (
'SL-20',
'NESEX',
20.81,
3112.85,
60 );

/* 21 */ 
INSERT INTO sales_financings 
VALUES (
'SL-21',
'UPPHA',
13.7,
3826.2,
24 );

/* 22 */ 
INSERT INTO sales_financings 
VALUES (
'SL-22',
'1FHMJ',
5.68,
5322.38,
36 );

/* 23 */ 
INSERT INTO sales_financings 
VALUES (
'SL-23',
'RN909',
7.48,
499.5,
24 );

/* 24 */ 
INSERT INTO sales_financings 
VALUES (
'SL-24',
'NESEX',
11.32,
4764.11,
48 );

/* 25 */ 
INSERT INTO sales_financings 
VALUES (
'SL-25',
'DYGU6',
7.75,
6966.36,
24 );

/* 26 */ 
INSERT INTO sales_financings 
VALUES (
'SL-26',
'L2KGH',
21.06,
5428.0,
36 );

/* 27 */ 
INSERT INTO sales_financings 
VALUES (
'SL-27',
'NESEX',
20.29,
5972.59,
60 );

/* 28 */ 
INSERT INTO sales_financings 
VALUES (
'SL-28',
'50LQ7',
2.68,
4715.23,
48 );

/* 29 */ 
INSERT INTO sales_financings 
VALUES (
'SL-29',
'DYGU6',
2.52,
3678.48,
36 );

/* 30 */ 
INSERT INTO sales_financings 
VALUES (
'SL-30',
'UPPHA',
13.96,
5922.84,
24 );

/* 31 */ 
INSERT INTO sales_financings 
VALUES (
'SL-31',
'RU80H',
9.1,
21994.14,
72 );

/* 32 */ 
INSERT INTO sales_financings 
VALUES (
'SL-32',
'RN909',
8.06,
5779.2,
24 );

/* 33 */ 
INSERT INTO sales_financings 
VALUES (
'SL-33',
'TDGXI',
20.09,
5298.12,
36 );

/* 34 */ 
INSERT INTO sales_financings 
VALUES (
'SL-34',
'6B68V',
15.93,
973.06,
24 );

/* 35 */ 
INSERT INTO sales_financings 
VALUES (
'SL-35',
'J4Z43',
18.89,
3299.38,
24 );

/* 36 */ 
INSERT INTO sales_financings 
VALUES (
'SL-36',
'BABVX',
7.46,
5314.84,
72 );

/* 37 */ 
INSERT INTO sales_financings 
VALUES (
'SL-37',
'HOB7D',
6.94,
4399.33,
36 );

/* 38 */ 
INSERT INTO sales_financings 
VALUES (
'SL-38',
'BABVX',
12.52,
24166.1,
36 );

/* 39 */ 
INSERT INTO sales_financings 
VALUES (
'SL-39',
'1FHMJ',
4.92,
3474.38,
24 );

/* 40 */ 
INSERT INTO sales_financings 
VALUES (
'SL-40',
'DYGU6',
3.16,
6033.42,
24 );

/* 41 */ 
INSERT INTO sales_financings 
VALUES (
'SL-41',
'UPPHA',
5.26,
5033.7,
24 );

/* 42 */ 
INSERT INTO sales_financings 
VALUES (
'SL-42',
'NESEX',
12.15,
5055.7,
36 );

/* 43 */ 
INSERT INTO sales_financings 
VALUES (
'SL-43',
'EJ2Y4',
8.82,
2689.56,
48 );

/* 44 */ 
INSERT INTO sales_financings 
VALUES (
'SL-44',
'DYGU6',
8.18,
3597.12,
24 );

/* 45 */ 
INSERT INTO sales_financings 
VALUES (
'SL-45',
'BABVX',
13.23,
4150.12,
36 );

/* 46 */ 
INSERT INTO sales_financings 
VALUES (
'SL-46',
'50LQ7',
5.32,
8388.69,
36 );

/* 47 */ 
INSERT INTO sales_financings 
VALUES (
'SL-47',
'1FHMJ',
12.07,
2916.2,
24 );

/* 48 */ 
INSERT INTO sales_financings 
VALUES (
'SL-48',
'6Y73V',
23.12,
6843.06,
48 );

/* 49 */ 
INSERT INTO sales_financings 
VALUES (
'SL-49',
'RN909',
6.23,
6891.45,
24 );

/* 50 */ 
INSERT INTO sales_financings 
VALUES (
'SL-50',
'L2KGH',
8.66,
4790.9,
24 );

/* 51 */ 
INSERT INTO sales_financings 
VALUES (
'SL-51',
'XU1I5',
10.14,
8728.06,
72 );

/* 52 */ 
INSERT INTO sales_financings 
VALUES (
'SL-52',
'L2KGH',
6.36,
7638.76,
60 );

/* 53 */ 
INSERT INTO sales_financings 
VALUES (
'SL-53',
'BABVX',
9.5,
8193.98,
48 );

/* 54 */ 
INSERT INTO sales_financings 
VALUES (
'SL-54',
'6Y73V',
15.81,
4421.16,
24 );

/* 55 */ 
INSERT INTO sales_financings 
VALUES (
'SL-55',
'HOB7D',
12.51,
19144.32,
36 );

/* 56 */ 
INSERT INTO sales_financings 
VALUES (
'SL-56',
'J4Z43',
15.23,
3404.66,
36 );

/* 57 */ 
INSERT INTO sales_financings 
VALUES (
'SL-57',
'TDGXI',
18.64,
4666.8,
60 );

/* 58 */ 
INSERT INTO sales_financings 
VALUES (
'SL-58',
'L2KGH',
18.3,
14567.28,
12 );

/* 59 */ 
INSERT INTO sales_financings 
VALUES (
'SL-59',
'1FHMJ',
7.39,
8961.26,
24 );

/* 60 */ 
INSERT INTO sales_financings 
VALUES (
'SL-60',
'6B68V',
20.71,
17530.15,
48 );

/* 61 */ 
INSERT INTO sales_financings 
VALUES (
'SL-61',
'L2KGH',
9.27,
6305.91,
72 );

/* 62 */ 
INSERT INTO sales_financings 
VALUES (
'SL-62',
'HOB7D',
11.19,
365.04,
36 );

/* 63 */ 
INSERT INTO sales_financings 
VALUES (
'SL-63',
'1FHMJ',
7.03,
936.18,
12 );

/* 64 */ 
INSERT INTO sales_financings 
VALUES (
'SL-64',
'50LQ7',
8.63,
3472.25,
36 );

/* 65 */ 
INSERT INTO sales_financings 
VALUES (
'SL-65',
'L1KEL',
8.07,
6192.32,
12 );

/* 66 */ 
INSERT INTO sales_financings 
VALUES (
'SL-66',
'L2KGH',
16.63,
6464.38,
24 );

/* 67 */ 
INSERT INTO sales_financings 
VALUES (
'SL-67',
'HOB7D',
4.34,
1860.17,
48 );

/* 68 */ 
INSERT INTO sales_financings 
VALUES (
'SL-68',
'BABVX',
13.79,
5593.37,
72 );

/* 69 */ 
INSERT INTO sales_financings 
VALUES (
'SL-69',
'L2KGH',
13.48,
7341.14,
60 );

/* 70 */ 
INSERT INTO sales_financings 
VALUES (
'SL-70',
'DYGU6',
4.14,
780.12,
48 );

/* 71 */ 
INSERT INTO sales_financings 
VALUES (
'SL-71',
'HOB7D',
5.17,
2345.72,
48 );

/* 72 */ 
INSERT INTO sales_financings 
VALUES (
'SL-72',
'1FHMJ',
4.72,
4365.06,
12 );

/* 73 */ 
INSERT INTO sales_financings 
VALUES (
'SL-73',
'UPPHA',
17.47,
32860.38,
60 );

/* 74 */ 
INSERT INTO sales_financings 
VALUES (
'SL-74',
'DYGU6',
6.93,
4521.78,
24 );

/* 75 */ 
INSERT INTO sales_financings 
VALUES (
'SL-75',
'1FHMJ',
5.07,
3304.0,
24 );

/* 76 */ 
INSERT INTO sales_financings 
VALUES (
'SL-76',
'DYGU6',
5.42,
3289.5,
48 );

/* 77 */ 
INSERT INTO sales_financings 
VALUES (
'SL-77',
'EJ2Y4',
8.11,
4275.12,
48 );

/* 78 */ 
INSERT INTO sales_financings 
VALUES (
'SL-78',
'50LQ7',
11.23,
22950.67,
36 );

/* 79 */ 
INSERT INTO sales_financings 
VALUES (
'SL-79',
'6Y73V',
2.09,
1154.52,
72 );

/* 80 */ 
INSERT INTO sales_financings 
VALUES (
'SL-80',
'NESEX',
13.66,
4543.24,
48 );

/* 81 */ 
INSERT INTO sales_financings 
VALUES (
'SL-81',
'L2KGH',
11.15,
4015.11,
48 );

/* 82 */ 
INSERT INTO sales_financings 
VALUES (
'SL-82',
'QCHGX',
8.87,
5554.22,
48 );

/* 83 */ 
INSERT INTO sales_financings 
VALUES (
'SL-83',
'RU80H',
8.27,
4293.24,
48 );

/* 84 */ 
INSERT INTO sales_financings 
VALUES (
'SL-84',
'6B68V',
3.85,
2149.62,
72 );

/* 85 */ 
INSERT INTO sales_financings 
VALUES (
'SL-85',
'RN909',
7.23,
2949.0,
12 );

/* 86 */ 
INSERT INTO sales_financings 
VALUES (
'SL-86',
'RU80H',
6.74,
3286.08,
60 );

/* 87 */ 
INSERT INTO sales_financings 
VALUES (
'SL-87',
'UPPHA',
21.29,
1901.97,
48 );

/* 88 */ 
INSERT INTO sales_financings 
VALUES (
'SL-88',
'BABVX',
10.05,
10154.73,
24 );

/* 89 */ 
INSERT INTO sales_financings 
VALUES (
'SL-89',
'L1KEL',
16.91,
1483.84,
24 );

/* 90 */ 
INSERT INTO sales_financings 
VALUES (
'SL-90',
'6Y73V',
3.36,
6099.3,
60 );

/* 91 */ 
INSERT INTO sales_financings 
VALUES (
'SL-91',
'J4Z43',
20.78,
4201.26,
36 );

/* 92 */ 
INSERT INTO sales_financings 
VALUES (
'SL-92',
'EJ2Y4',
7.06,
20021.04,
60 );

/* 93 */ 
INSERT INTO sales_financings 
VALUES (
'SL-93',
'TDGXI',
14.42,
1730.76,
60 );

/* 94 */ 
INSERT INTO sales_financings 
VALUES (
'SL-94',
'50LQ7',
2.51,
5358.76,
60 );

/* 95 */ 
INSERT INTO sales_financings 
VALUES (
'SL-95',
'J4Z43',
20.73,
1298.36,
48 );

/* 96 */ 
INSERT INTO sales_financings 
VALUES (
'SL-96',
'L2KGH',
19.7,
9900.81,
24 );

/* 97 */ 
INSERT INTO sales_financings 
VALUES (
'SL-97',
'6B68V',
18.12,
18352.62,
12 );

/* 98 */ 
INSERT INTO sales_financings 
VALUES (
'SL-98',
'BABVX',
12.35,
3155.83,
60 );

/* 99 */ 
INSERT INTO sales_financings 
VALUES (
'SL-99',
'HOB7D',
11.18,
4317.56,
36 );

/* 100 */ 
INSERT INTO sales_financings 
VALUES (
'SL-100',
'L1KEL',
14.2,
5591.68,
36 );

/* 101 */ 
INSERT INTO sales_financings 
VALUES (
'SL-101',
'LOPXQ',
9.06,
10107.46,
72 );

/* 102 */ 
INSERT INTO sales_financings 
VALUES (
'SL-102',
'L2KGH',
15.16,
35989.94,
12 );

/* 103 */ 
INSERT INTO sales_financings 
VALUES (
'SL-103',
'NESEX',
21.81,
5582.59,
36 );

/* 104 */ 
INSERT INTO sales_financings 
VALUES (
'SL-104',
'1FHMJ',
4.85,
1298.36,
36 );

/* 105 */ 
INSERT INTO sales_financings 
VALUES (
'SL-105',
'L2KGH',
19.88,
6366.86,
24 );

/* 106 */ 
INSERT INTO sales_financings 
VALUES (
'SL-106',
'BABVX',
18.25,
6741.99,
36 );

/* 107 */ 
INSERT INTO sales_financings 
VALUES (
'SL-107',
'XU1I5',
9.81,
9496.3,
48 );

/* 108 */ 
INSERT INTO sales_financings 
VALUES (
'SL-108',
'50LQ7',
8.94,
3796.96,
48 );

/* 109 */ 
INSERT INTO sales_financings 
VALUES (
'SL-109',
'J4Z43',
15.82,
12467.42,
48 );

/* 110 */ 
INSERT INTO sales_financings 
VALUES (
'SL-110',
'50LQ7',
11.01,
4258.47,
72 );

/* 111 */ 
INSERT INTO sales_financings 
VALUES (
'SL-111',
'HOB7D',
11.07,
4543.24,
24 );

/* 112 */ 
INSERT INTO sales_financings 
VALUES (
'SL-112',
'NESEX',
18.92,
2579.2,
36 );

/* 113 */ 
INSERT INTO sales_financings 
VALUES (
'SL-113',
'EJ2Y4',
7.88,
2186.4,
48 );

/* 114 */ 
INSERT INTO sales_financings 
VALUES (
'SL-114',
'LOPXQ',
14.92,
732.6,
72 );

/* 115 */ 
INSERT INTO sales_financings 
VALUES (
'SL-115',
'NESEX',
12.0,
3193.06,
60 );

/* 116 */ 
INSERT INTO sales_financings 
VALUES (
'SL-116',
'L1KEL',
18.44,
5363.04,
48 );

/* 117 */ 
INSERT INTO sales_financings 
VALUES (
'SL-117',
'HOB7D',
6.96,
3598.66,
12 );

/* 118 */ 
INSERT INTO sales_financings 
VALUES (
'SL-118',
'1FHMJ',
5.29,
5393.92,
36 );

/* 119 */ 
INSERT INTO sales_financings 
VALUES (
'SL-119',
'1FHMJ',
11.48,
2137.24,
48 );

/* 120 */ 
INSERT INTO sales_financings 
VALUES (
'SL-120',
'6Y73V',
16.46,
4248.0,
60 );

/* 121 */ 
INSERT INTO sales_financings 
VALUES (
'SL-121',
'TDGXI',
18.69,
2453.04,
72 );

/* 122 */ 
INSERT INTO sales_financings 
VALUES (
'SL-122',
'50LQ7',
11.34,
8729.17,
36 );

/* 123 */ 
INSERT INTO sales_financings 
VALUES (
'SL-123',
'XU1I5',
21.6,
34562.22,
24 );

/* 124 */ 
INSERT INTO sales_financings 
VALUES (
'SL-124',
'6Y73V',
10.01,
3864.6,
60 );

/* 125 */ 
INSERT INTO sales_financings 
VALUES (
'SL-125',
'L2KGH',
12.91,
10839.21,
24 );

/* 126 */ 
INSERT INTO sales_financings 
VALUES (
'SL-126',
'L2KGH',
6.7,
5707.91,
36 );

/* 127 */ 
INSERT INTO sales_financings 
VALUES (
'SL-127',
'DYGU6',
7.79,
3538.8,
36 );

/* 128 */ 
INSERT INTO sales_financings 
VALUES (
'SL-128',
'50LQ7',
6.57,
6962.93,
72 );

/* 129 */ 
INSERT INTO sales_financings 
VALUES (
'SL-129',
'EJ2Y4',
7.68,
2772.96,
12 );

/* 130 */ 
INSERT INTO sales_financings 
VALUES (
'SL-130',
'6B68V',
12.64,
1984.84,
48 );

/* 131 */ 
INSERT INTO sales_financings 
VALUES (
'SL-131',
'6Y73V',
14.81,
4238.64,
24 );

/* 132 */ 
INSERT INTO sales_financings 
VALUES (
'SL-132',
'QCHGX',
9.04,
6142.92,
24 );

/* 133 */ 
INSERT INTO sales_financings 
VALUES (
'SL-133',
'QCHGX',
11.01,
3999.1,
60 );

/* 134 */ 
INSERT INTO sales_financings 
VALUES (
'SL-134',
'HOB7D',
6.9,
5017.87,
36 );

/* 135 */ 
INSERT INTO sales_financings 
VALUES (
'SL-135',
'LOPXQ',
14.12,
7306.64,
48 );

/* 136 */ 
INSERT INTO sales_financings 
VALUES (
'SL-136',
'TDGXI',
16.21,
3290.04,
48 );

/* 137 */ 
INSERT INTO sales_financings 
VALUES (
'SL-137',
'DYGU6',
2.21,
23474.34,
12 );

/* 138 */ 
INSERT INTO sales_financings 
VALUES (
'SL-138',
'50LQ7',
9.19,
5340.14,
60 );

/* 139 */ 
INSERT INTO sales_financings 
VALUES (
'SL-139',
'LOPXQ',
9.11,
4497.24,
60 );

/* 140 */ 
INSERT INTO sales_financings 
VALUES (
'SL-140',
'4QL2J',
11.01,
8201.35,
24 );

/* 141 */ 
INSERT INTO sales_financings 
VALUES (
'SL-141',
'50LQ7',
2.58,
12927.41,
36 );

/* 142 */ 
INSERT INTO sales_financings 
VALUES (
'SL-142',
'6Y73V',
1.16,
4836.96,
60 );

/* 143 */ 
INSERT INTO sales_financings 
VALUES (
'SL-143',
'L1KEL',
13.12,
3916.16,
36 );

/* 144 */ 
INSERT INTO sales_financings 
VALUES (
'SL-144',
'EJ2Y4',
8.92,
1681.2,
60 );

/* 145 */ 
INSERT INTO sales_financings 
VALUES (
'SL-145',
'BABVX',
17.72,
286.35,
60 );

/* 146 */ 
INSERT INTO sales_financings 
VALUES (
'SL-146',
'BABVX',
17.84,
9665.06,
60 );

/* 147 */ 
INSERT INTO sales_financings 
VALUES (
'SL-147',
'L1KEL',
20.65,
5932.0,
36 );

/* 148 */ 
INSERT INTO sales_financings 
VALUES (
'SL-148',
'LOPXQ',
14.36,
32398.08,
72 );

/* 149 */ 
INSERT INTO sales_financings 
VALUES (
'SL-149',
'NESEX',
5.86,
450.06,
48 );

/* 150 */ 
INSERT INTO sales_financings 
VALUES (
'SL-150',
'L1KEL',
21.02,
1611.36,
12 );

/* 151 */ 
INSERT INTO sales_financings 
VALUES (
'SL-151',
'6B68V',
7.21,
3649.14,
72 );

/* 152 */ 
INSERT INTO sales_financings 
VALUES (
'SL-152',
'LOPXQ',
13.95,
6678.76,
36 );

/* 153 */ 
INSERT INTO sales_financings 
VALUES (
'SL-153',
'L2KGH',
10.2,
14369.94,
60 );

/* 154 */ 
INSERT INTO sales_financings 
VALUES (
'SL-154',
'L2KGH',
7.84,
6209.08,
24 );

/* 155 */ 
INSERT INTO sales_financings 
VALUES (
'SL-155',
'HOB7D',
10.95,
5020.86,
12 );

/* 156 */ 
INSERT INTO sales_financings 
VALUES (
'SL-156',
'HOB7D',
12.44,
21689.46,
48 );

/* 157 */ 
INSERT INTO sales_financings 
VALUES (
'SL-157',
'L2KGH',
8.15,
5885.7,
36 );

/* 158 */ 
INSERT INTO sales_financings 
VALUES (
'SL-158',
'DYGU6',
1.84,
4159.44,
48 );

/* 159 */ 
INSERT INTO sales_financings 
VALUES (
'SL-159',
'6B68V',
19.55,
3722.51,
24 );

/* 160 */ 
INSERT INTO sales_financings 
VALUES (
'SL-160',
'XU1I5',
18.34,
34562.22,
36 );

/* 161 */ 
INSERT INTO sales_financings 
VALUES (
'SL-161',
'4QL2J',
12.69,
8201.35,
36 );

/* 162 */ 
INSERT INTO sales_financings 
VALUES (
'SL-162',
'EJ2Y4',
8.17,
12608.4,
60 );

/* 163 */ 
INSERT INTO sales_financings 
VALUES (
'SL-163',
'BABVX',
8.86,
5629.48,
24 );

/* 164 */ 
INSERT INTO sales_financings 
VALUES (
'SL-164',
'LOPXQ',
15.04,
7298.28,
72 );

/* 165 */ 
INSERT INTO sales_financings 
VALUES (
'SL-165',
'1FHMJ',
3.87,
2003.26,
24 );

/* 166 */ 
INSERT INTO sales_financings 
VALUES (
'SL-166',
'LOPXQ',
12.72,
761.64,
36 );

/* 167 */ 
INSERT INTO sales_financings 
VALUES (
'SL-167',
'QCHGX',
9.92,
7983.36,
24 );

/* 168 */ 
INSERT INTO sales_financings 
VALUES (
'SL-168',
'4QL2J',
10.04,
9577.33,
12 );

/* 169 */ 
INSERT INTO sales_financings 
VALUES (
'SL-169',
'L1KEL',
16.27,
6250.08,
24 );

/* 170 */ 
INSERT INTO sales_financings 
VALUES (
'SL-170',
'BABVX',
11.3,
2316.33,
36 );

/* 171 */ 
INSERT INTO sales_financings 
VALUES (
'SL-171',
'50LQ7',
6.16,
30279.35,
36 );

/* 172 */ 
INSERT INTO sales_financings 
VALUES (
'SL-172',
'6B68V',
7.82,
180.4,
48 );

/* 173 */ 
INSERT INTO sales_financings 
VALUES (
'SL-173',
'RU80H',
5.79,
3999.1,
72 );

/* 174 */ 
INSERT INTO sales_financings 
VALUES (
'SL-174',
'QCHGX',
8.06,
3286.08,
48 );

/* 175 */ 
INSERT INTO sales_financings 
VALUES (
'SL-175',
'6Y73V',
23.04,
28166.04,
48 );

/* 176 */ 
INSERT INTO sales_financings 
VALUES (
'SL-176',
'J4Z43',
17.13,
4692.66,
48 );

/* 177 */ 
INSERT INTO sales_financings 
VALUES (
'SL-177',
'BABVX',
14.14,
7630.02,
24 );

/* 178 */ 
INSERT INTO sales_financings 
VALUES (
'SL-178',
'6B68V',
4.26,
1509.31,
72 );

/* 179 */ 
INSERT INTO sales_financings 
VALUES (
'SL-179',
'L1KEL',
11.51,
2307.68,
48 );

/* 180 */ 
INSERT INTO sales_financings 
VALUES (
'SL-180',
'UPPHA',
20.74,
4103.82,
36 );

/* 181 */ 
INSERT INTO sales_financings 
VALUES (
'SL-181',
'6B68V',
3.02,
2465.76,
36 );

/* 182 */ 
INSERT INTO sales_financings 
VALUES (
'SL-182',
'HOB7D',
4.89,
3653.78,
48 );

/* 183 */ 
INSERT INTO sales_financings 
VALUES (
'SL-183',
'L1KEL',
10.21,
2793.12,
60 );

/* 184 */ 
INSERT INTO sales_financings 
VALUES (
'SL-184',
'DYGU6',
3.89,
295.2,
24 );

/* 185 */ 
INSERT INTO sales_financings 
VALUES (
'SL-185',
'HOB7D',
11.82,
4317.56,
24 );

/* 186 */ 
INSERT INTO sales_financings 
VALUES (
'SL-186',
'BABVX',
12.07,
11174.55,
72 );

/* 187 */ 
INSERT INTO sales_financings 
VALUES (
'SL-187',
'HOB7D',
11.11,
833.82,
12 );

/* 188 */ 
INSERT INTO sales_financings 
VALUES (
'SL-188',
'6Y73V',
19.75,
4859.28,
72 );

/* 189 */ 
INSERT INTO sales_financings 
VALUES (
'SL-189',
'L1KEL',
16.98,
6082.72,
12 );

/* 190 */ 
INSERT INTO sales_financings 
VALUES (
'SL-190',
'LOPXQ',
12.79,
8156.5,
48 );

/* 191 */ 
INSERT INTO sales_financings 
VALUES (
'SL-191',
'TDGXI',
18.12,
336.96,
72 );

/* 192 */ 
INSERT INTO sales_financings 
VALUES (
'SL-192',
'L1KEL',
12.34,
4326.24,
48 );

/* 193 */ 
INSERT INTO sales_financings 
VALUES (
'SL-193',
'L1KEL',
9.83,
3929.92,
48 );

/* 194 */ 
INSERT INTO sales_financings 
VALUES (
'SL-194',
'1FHMJ',
10.18,
6181.14,
36 );

/* 195 */ 
INSERT INTO sales_financings 
VALUES (
'SL-195',
'BABVX',
8.42,
5649.26,
24 );

/* 196 */ 
INSERT INTO sales_financings 
VALUES (
'SL-196',
'50LQ7',
7.97,
12077.35,
36 );

/* 197 */ 
INSERT INTO sales_financings 
VALUES (
'SL-197',
'6B68V',
7.94,
2291.3,
72 );

/* 198 */ 
INSERT INTO sales_financings 
VALUES (
'SL-198',
'EJ2Y4',
8.66,
1112.88,
12 );

/* 199 */ 
INSERT INTO sales_financings 
VALUES (
'SL-199',
'6Y73V',
5.8,
4034.34,
72 );

/* 200 */ 
INSERT INTO sales_financings 
VALUES (
'SL-200',
'HOB7D',
9.02,
4819.75,
24 );

/* 201 */ 
INSERT INTO sales_financings 
VALUES (
'SL-201',
'TDGXI',
15.96,
3642.36,
24 );

/* 202 */ 
INSERT INTO sales_financings 
VALUES (
'SL-202',
'LOPXQ',
16.29,
26574.46,
60 );

/* 203 */ 
INSERT INTO sales_financings 
VALUES (
'SL-203',
'HOB7D',
4.53,
2540.46,
48 );

/* 204 */ 
INSERT INTO sales_financings 
VALUES (
'SL-204',
'HOB7D',
7.74,
4502.03,
48 );

/* 205 */ 
INSERT INTO sales_financings 
VALUES (
'SL-205',
'J4Z43',
15.04,
6012.02,
12 );

/* 206 */ 
INSERT INTO sales_financings 
VALUES (
'SL-206',
'TDGXI',
8.08,
3274.92,
72 );

/* 207 */ 
INSERT INTO sales_financings 
VALUES (
'SL-207',
'BABVX',
19.74,
8527.25,
72 );

/* 208 */ 
INSERT INTO sales_financings 
VALUES (
'SL-208',
'XU1I5',
15.87,
6284.3,
36 );

/* 209 */ 
INSERT INTO sales_financings 
VALUES (
'SL-209',
'NESEX',
11.13,
2914.08,
60 );

/* 210 */ 
INSERT INTO sales_financings 
VALUES (
'SL-210',
'UPPHA',
21.15,
5643.12,
36 );

/* 211 */ 
INSERT INTO sales_financings 
VALUES (
'SL-211',
'QCHGX',
11.06,
5554.22,
24 );

/* 212 */ 
INSERT INTO sales_financings 
VALUES (
'SL-212',
'L1KEL',
10.45,
6250.08,
48 );

/* 213 */ 
INSERT INTO sales_financings 
VALUES (
'SL-213',
'J4Z43',
18.27,
4743.9,
36 );

/* 214 */ 
INSERT INTO sales_financings 
VALUES (
'SL-214',
'DYGU6',
5.06,
4430.34,
48 );

/* 215 */ 
INSERT INTO sales_financings 
VALUES (
'SL-215',
'L2KGH',
14.36,
5543.46,
36 );

/* 216 */ 
INSERT INTO sales_financings 
VALUES (
'SL-216',
'L1KEL',
9.76,
10241.44,
24 );

/* 217 */ 
INSERT INTO sales_financings 
VALUES (
'SL-217',
'6Y73V',
17.16,
7947.18,
24 );

/* 218 */ 
INSERT INTO sales_financings 
VALUES (
'SL-218',
'LOPXQ',
12.96,
8062.34,
48 );

/* 219 */ 
INSERT INTO sales_financings 
VALUES (
'SL-219',
'L2KGH',
21.1,
10566.89,
72 );

/* 220 */ 
INSERT INTO sales_financings 
VALUES (
'SL-220',
'BABVX',
18.74,
13279.74,
72 );

/* 221 */ 
INSERT INTO sales_financings 
VALUES (
'SL-221',
'50LQ7',
2.25,
5137.41,
72 );

/* 222 */ 
INSERT INTO sales_financings 
VALUES (
'SL-222',
'6Y73V',
1.53,
7563.96,
36 );

/* 223 */ 
INSERT INTO sales_financings 
VALUES (
'SL-223',
'BABVX',
15.69,
8901.46,
36 );

/* 224 */ 
INSERT INTO sales_financings 
VALUES (
'SL-224',
'UPPHA',
9.67,
4956.0,
24 );

/* 225 */ 
INSERT INTO sales_financings 
VALUES (
'SL-225',
'6B68V',
16.9,
2974.29,
60 );

/* 226 */ 
INSERT INTO sales_financings 
VALUES (
'SL-226',
'J4Z43',
13.8,
3443.02,
48 );

/* 227 */ 
INSERT INTO sales_financings 
VALUES (
'SL-227',
'XU1I5',
7.8,
5163.84,
24 );

/* 228 */ 
INSERT INTO sales_financings 
VALUES (
'SL-228',
'HOB7D',
5.94,
6763.38,
36 );

/* 229 */ 
INSERT INTO sales_financings 
VALUES (
'SL-229',
'6B68V',
4.16,
4829.66,
12 );

/* 230 */ 
INSERT INTO sales_financings 
VALUES (
'SL-230',
'BABVX',
15.95,
645.84,
72 );

/* 231 */ 
INSERT INTO sales_financings 
VALUES (
'SL-231',
'1FHMJ',
7.79,
8083.32,
60 );

/* 232 */ 
INSERT INTO sales_financings 
VALUES (
'SL-232',
'J4Z43',
21.05,
11672.22,
36 );

/* 233 */ 
INSERT INTO sales_financings 
VALUES (
'SL-233',
'50LQ7',
5.35,
6640.12,
72 );

/* 234 */ 
INSERT INTO sales_financings 
VALUES (
'SL-234',
'DYGU6',
5.36,
7903.08,
12 );

/* 235 */ 
INSERT INTO sales_financings 
VALUES (
'SL-235',
'TDGXI',
11.52,
5327.16,
60 );

/* 236 */ 
INSERT INTO sales_financings 
VALUES (
'SL-236',
'6Y73V',
7.49,
6673.5,
24 );

/* 237 */ 
INSERT INTO sales_financings 
VALUES (
'SL-237',
'L1KEL',
14.79,
5414.56,
12 );

/* 238 */ 
INSERT INTO sales_financings 
VALUES (
'SL-238',
'L1KEL',
14.91,
6222.4,
60 );

/* 239 */ 
INSERT INTO sales_financings 
VALUES (
'SL-239',
'1FHMJ',
11.47,
4250.12,
24 );

/* 240 */ 
INSERT INTO sales_financings 
VALUES (
'SL-240',
'50LQ7',
7.24,
6397.87,
36 );

/* 241 */ 
INSERT INTO sales_financings 
VALUES (
'SL-241',
'RN909',
7.47,
5050.95,
24 );

/* 242 */ 
INSERT INTO sales_financings 
VALUES (
'SL-242',
'NESEX',
8.9,
1149.98,
60 );

/* 243 */ 
INSERT INTO sales_financings 
VALUES (
'SL-243',
'LOPXQ',
9.26,
14081.98,
60 );

/* 244 */ 
INSERT INTO sales_financings 
VALUES (
'SL-244',
'6B68V',
4.21,
1573.99,
48 );

/* 245 */ 
INSERT INTO sales_financings 
VALUES (
'SL-245',
'EJ2Y4',
7.94,
2186.4,
24 );

/* 246 */ 
INSERT INTO sales_financings 
VALUES (
'SL-246',
'TDGXI',
19.38,
3070.8,
24 );

/* 247 */ 
INSERT INTO sales_financings 
VALUES (
'SL-247',
'TDGXI',
19.59,
4666.8,
48 );

/* 248 */ 
INSERT INTO sales_financings 
VALUES (
'SL-248',
'DYGU6',
3.56,
5401.62,
24 );

/* 249 */ 
INSERT INTO sales_financings 
VALUES (
'SL-249',
'DYGU6',
7.23,
7729.74,
12 );

/* 250 */ 
INSERT INTO sales_financings 
VALUES (
'SL-250',
'LOPXQ',
14.19,
7688.56,
72 );

/* 251 */ 
INSERT INTO sales_financings 
VALUES (
'SL-251',
'BABVX',
11.21,
2083.11,
72 );

/* 252 */ 
INSERT INTO sales_financings 
VALUES (
'SL-252',
'XU1I5',
9.06,
9496.3,
12 );

/* 253 */ 
INSERT INTO sales_financings 
VALUES (
'SL-253',
'LOPXQ',
11.26,
5384.72,
72 );

/* 254 */ 
INSERT INTO sales_financings 
VALUES (
'SL-254',
'6Y73V',
2.52,
3864.6,
72 );

/* 255 */ 
INSERT INTO sales_financings 
VALUES (
'SL-255',
'L1KEL',
21.0,
3938.08,
60 );

/* 256 */ 
INSERT INTO sales_financings 
VALUES (
'SL-256',
'4QL2J',
17.86,
8336.82,
48 );

/* 257 */ 
INSERT INTO sales_financings 
VALUES (
'SL-257',
'50LQ7',
4.93,
311.6,
72 );

/* 258 */ 
INSERT INTO sales_financings 
VALUES (
'SL-258',
'BABVX',
11.53,
7793.55,
48 );

/* 259 */ 
INSERT INTO sales_financings 
VALUES (
'SL-259',
'LOPXQ',
13.19,
5267.9,
48 );

/* 260 */ 
INSERT INTO sales_financings 
VALUES (
'SL-260',
'TDGXI',
13.85,
1061.52,
36 );

/* 261 */ 
INSERT INTO sales_financings 
VALUES (
'SL-261',
'QCHGX',
10.67,
3286.08,
60 );

/* 262 */ 
INSERT INTO sales_financings 
VALUES (
'SL-262',
'UPPHA',
14.71,
5106.99,
48 );

/* 263 */ 
INSERT INTO sales_financings 
VALUES (
'SL-263',
'L2KGH',
19.84,
8877.77,
24 );

/* 264 */ 
INSERT INTO sales_financings 
VALUES (
'SL-264',
'TDGXI',
17.36,
18777.36,
60 );

/* 265 */ 
INSERT INTO sales_financings 
VALUES (
'SL-265',
'RN909',
5.96,
5723.4,
60 );

/* 266 */ 
INSERT INTO sales_financings 
VALUES (
'SL-266',
'BABVX',
14.96,
10839.21,
36 );

/* 267 */ 
INSERT INTO sales_financings 
VALUES (
'SL-267',
'6B68V',
18.72,
4245.89,
48 );

/* 268 */ 
INSERT INTO sales_financings 
VALUES (
'SL-268',
'UPPHA',
21.81,
6374.13,
48 );

/* 269 */ 
INSERT INTO sales_financings 
VALUES (
'SL-269',
'RN909',
7.83,
2949.0,
12 );

/* 270 */ 
INSERT INTO sales_financings 
VALUES (
'SL-270',
'DYGU6',
5.43,
2747.88,
36 );

/* 271 */ 
INSERT INTO sales_financings 
VALUES (
'SL-271',
'NESEX',
11.69,
2878.46,
36 );

/* 272 */ 
INSERT INTO sales_financings 
VALUES (
'SL-272',
'BABVX',
9.17,
6981.19,
36 );

/* 273 */ 
INSERT INTO sales_financings 
VALUES (
'SL-273',
'6B68V',
15.61,
2763.31,
12 );

/* 274 */ 
INSERT INTO sales_financings 
VALUES (
'SL-274',
'6Y73V',
2.12,
780.12,
72 );

/* 275 */ 
INSERT INTO sales_financings 
VALUES (
'SL-275',
'EJ2Y4',
7.16,
2953.56,
36 );

/* 276 */ 
INSERT INTO sales_financings 
VALUES (
'SL-276',
'J4Z43',
14.84,
1298.36,
24 );

/* 277 */ 
INSERT INTO sales_financings 
VALUES (
'SL-277',
'J4Z43',
10.62,
2861.88,
24 );

/* 278 */ 
INSERT INTO sales_financings 
VALUES (
'SL-278',
'LOPXQ',
14.01,
3082.2,
72 );

/* 279 */ 
INSERT INTO sales_financings 
VALUES (
'SL-279',
'J4Z43',
19.12,
2526.16,
12 );

/* 280 */ 
INSERT INTO sales_financings 
VALUES (
'SL-280',
'NESEX',
12.59,
6763.38,
60 );

/* 281 */ 
INSERT INTO sales_financings 
VALUES (
'SL-281',
'1FHMJ',
9.67,
11672.22,
24 );

/* 282 */ 
INSERT INTO sales_financings 
VALUES (
'SL-282',
'6B68V',
14.88,
3338.83,
12 );

/* 283 */ 
INSERT INTO sales_financings 
VALUES (
'SL-283',
'UPPHA',
20.51,
4649.82,
60 );

/* 284 */ 
INSERT INTO sales_financings 
VALUES (
'SL-284',
'1FHMJ',
5.28,
5393.92,
60 );

/* 285 */ 
INSERT INTO sales_financings 
VALUES (
'SL-285',
'EJ2Y4',
8.17,
5042.64,
12 );

/* 286 */ 
INSERT INTO sales_financings 
VALUES (
'SL-286',
'6B68V',
21.97,
1020.14,
36 );

/* 287 */ 
INSERT INTO sales_financings 
VALUES (
'SL-287',
'L1KEL',
7.87,
4512.64,
60 );

/* 288 */ 
INSERT INTO sales_financings 
VALUES (
'SL-288',
'6Y73V',
24.73,
3749.4,
60 );

/* 289 */ 
INSERT INTO sales_financings 
VALUES (
'SL-289',
'DYGU6',
7.46,
5971.32,
36 );

/* 290 */ 
INSERT INTO sales_financings 
VALUES (
'SL-290',
'EJ2Y4',
8.31,
18777.36,
60 );

/* 291 */ 
INSERT INTO sales_financings 
VALUES (
'SL-291',
'DYGU6',
3.59,
6843.06,
36 );

/* 292 */ 
INSERT INTO sales_financings 
VALUES (
'SL-292',
'6Y73V',
21.01,
30031.56,
72 );

/* 293 */ 
INSERT INTO sales_financings 
VALUES (
'SL-293',
'LOPXQ',
13.42,
5939.12,
36 );

/* 294 */ 
INSERT INTO sales_financings 
VALUES (
'SL-294',
'NESEX',
7.23,
5582.59,
60 );

/* 295 */ 
INSERT INTO sales_financings 
VALUES (
'SL-295',
'6Y73V',
17.94,
21742.74,
36 );

/* 296 */ 
INSERT INTO sales_financings 
VALUES (
'SL-296',
'UPPHA',
9.54,
5731.11,
48 );

/* 297 */ 
INSERT INTO sales_financings 
VALUES (
'SL-297',
'4QL2J',
18.0,
4459.68,
48 );

/* 298 */ 
INSERT INTO sales_financings 
VALUES (
'SL-298',
'NESEX',
6.1,
1309.23,
36 );

/* 299 */ 
INSERT INTO sales_financings 
VALUES (
'SL-299',
'L1KEL',
22.5,
4690.08,
12 );

/* 300 */ 
INSERT INTO sales_financings 
VALUES (
'SL-300',
'LOPXQ',
16.3,
5184.74,
60 );

