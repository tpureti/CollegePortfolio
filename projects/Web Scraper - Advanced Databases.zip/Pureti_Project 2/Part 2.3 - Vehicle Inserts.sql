/* 1 */ 
INSERT INTO vehicles (vehicle_id, year, make, model, trim, type, wholesale_cost, dealer_id) 
VALUES (
'TF94395R',
2019,
'Toyota',
'Tundra',
'Platinum',
'Pickup',
39804,
'Y',
'XCC-7751' );

/* 2 */ 
INSERT INTO vehicles 
VALUES (
'FY97403H',
2017,
'Kia',
'Optima Plug-In Hybrid',
'EX',
'Sedan',
19362,
'Y',
'FTG-3501' );

/* 3 */ 
INSERT INTO vehicles 
VALUES (
'YU94990T',
2017,
'GMC',
'Yukon',
'Denali',
'SUV',
44266,
'Y',
'SHH-8476' );

/* 4 */ 
INSERT INTO vehicles 
VALUES (
'ZS15908X',
2021,
'Jeep',
'Cherokee',
'High Altitude',
'SUV',
37953,
'N',
'NDR-2833' );

/* 5 */ 
INSERT INTO vehicles 
VALUES (
'AT52450G',
2019,
'Audi',
'A8',
'L 4.0 TFSI quattro',
'Sedan',
56571,
'Y',
'XCC-7751' );

/* 6 */ 
INSERT INTO vehicles 
VALUES (
'FE06996Q',
2017,
'Mercedes-Benz',
'B-Class Electric Drive',
'B 250e',
'Hatchback',
15945,
'Y',
'KRA-8632' );

/* 7 */ 
INSERT INTO vehicles 
VALUES (
'KK29903Z',
2018,
'Audi',
'Q3',
'Premium quattro',
'SUV',
21874,
'Y',
'XBV-0028' );

/* 8 */ 
INSERT INTO vehicles 
VALUES (
'BZ07352L',
1999,
'GMC',
'Savana Cargo',
'G2500',
'Van/Minivan',
967,
'Y',
'ZBG-5371' );

/* 9 */ 
INSERT INTO vehicles 
VALUES (
'VS26277G',
2017,
'Hyundai',
'Sonata',
'Sport 2.0T',
'Sedan',
14512,
'Y',
'WAI-2368' );

/* 10 */ 
INSERT INTO vehicles 
VALUES (
'MC84938W',
2016,
'Chevrolet',
'SS',
'',
'Sedan',
33605,
'Y',
'WQC-0160' );

/* 11 */ 
INSERT INTO vehicles 
VALUES (
'TI77231U',
2020,
'Jeep',
'Cherokee',
'High Altitude',
'SUV',
25583,
'Y',
'WQC-0160' );

/* 12 */ 
INSERT INTO vehicles 
VALUES (
'QB98653I',
2020,
'INFINITI',
'QX50',
'SENSORY',
'SUV',
37938,
'Y',
'QPL-3867' );

/* 13 */ 
INSERT INTO vehicles 
VALUES (
'VU32342X',
2020,
'Toyota',
'Tacoma',
'Limited',
'Pickup',
36303,
'Y',
'FTG-3501' );

/* 14 */ 
INSERT INTO vehicles 
VALUES (
'PE18122D',
2013,
'Ford',
'Flex',
'Limited',
'SUV',
9084,
'Y',
'XCC-7751' );

/* 15 */ 
INSERT INTO vehicles 
VALUES (
'BU64332M',
2002,
'Audi',
'S8',
'quattro',
'Sedan',
2274,
'Y',
'FGE-8272' );

/* 16 */ 
INSERT INTO vehicles 
VALUES (
'TK73056Y',
2019,
'Ford',
'Transit Van',
'150 Low Roof',
'Van/Minivan',
33349,
'Y',
'XCC-7751' );

/* 17 */ 
INSERT INTO vehicles 
VALUES (
'SB59348T',
2017,
'Rolls-Royce',
'Wraith',
'',
'Coupe',
138219,
'Y',
'ELX-3440' );

/* 18 */ 
INSERT INTO vehicles 
VALUES (
'NC45224P',
2018,
'Ford',
'Explorer',
'Limited',
'SUV',
29245,
'Y',
'MMN-8574' );

/* 19 */ 
INSERT INTO vehicles 
VALUES (
'BH11164E',
2019,
'Chevrolet',
'Express Cargo',
'3500',
'Van/Minivan',
30503,
'Y',
'WQC-0160' );

/* 20 */ 
INSERT INTO vehicles 
VALUES (
'ZF51944O',
2009,
'Dodge',
'Ram Pickup 3500',
'ST',
'Pickup',
9687,
'Y',
'ELX-3440' );

/* 21 */ 
INSERT INTO vehicles 
VALUES (
'ZR99790S',
2020,
'Hyundai',
'Veloster',
'2.0 Premium',
'Coupe',
21366,
'Y',
'XVU-1597' );

/* 22 */ 
INSERT INTO vehicles 
VALUES (
'NG99424A',
2018,
'Hyundai',
'Santa Fe',
'Limited Ultimate',
'SUV',
27859,
'Y',
'FGE-8272' );

/* 23 */ 
INSERT INTO vehicles 
VALUES (
'LM31352H',
2014,
'Mercedes-Benz',
'Sprinter',
'2500 170 WB Cargo',
'Van/Minivan',
20830,
'Y',
'ELX-3440' );

/* 24 */ 
INSERT INTO vehicles 
VALUES (
'SW51156D',
2017,
'Ford',
'F-350 Super Duty',
'Lariat',
'Pickup',
36179,
'Y',
'MMN-8574' );

/* 25 */ 
INSERT INTO vehicles 
VALUES (
'EI61295J',
2018,
'Mitsubishi',
'Mirage G4',
'SE',
'Sedan',
9157,
'Y',
'LAC-2227' );

/* 26 */ 
INSERT INTO vehicles 
VALUES (
'MD71129J',
2016,
'Ferrari',
'488 GTB',
'',
'Coupe',
119253,
'Y',
'NDR-2833' );

/* 27 */ 
INSERT INTO vehicles 
VALUES (
'WI46738L',
2010,
'Chevrolet',
'Express',
'LS 2500',
'Van/Minivan',
5647,
'Y',
'LYO-7631' );

/* 28 */ 
INSERT INTO vehicles 
VALUES (
'VQ30141P',
2020,
'Land Rover',
'Range Rover Sport',
'P525 Autobiography',
'SUV',
83306,
'Y',
'XVU-1597' );

/* 29 */ 
INSERT INTO vehicles 
VALUES (
'UQ95030G',
2016,
'Land Rover',
'LR4',
'',
'SUV',
27314,
'Y',
'XCC-7751' );

/* 30 */ 
INSERT INTO vehicles 
VALUES (
'TI13578G',
2008,
'Ford',
'Ranger',
'FX4 Off-Road',
'Pickup',
3043,
'Y',
'FGE-8272' );

/* 31 */ 
INSERT INTO vehicles 
VALUES (
'KS46200Z',
2021,
'GMC',
'Yukon XL',
'SLE',
'SUV',
52757,
'N',
'ORP-8078' );

/* 32 */ 
INSERT INTO vehicles 
VALUES (
'FG40524S',
2002,
'Kia',
'Rio',
'',
'Wagon',
805,
'Y',
'QPL-3867' );

/* 33 */ 
INSERT INTO vehicles 
VALUES (
'RU30924P',
2017,
'Nissan',
'Titan XD',
'SV',
'Pickup',
22745,
'Y',
'JWE-6313' );

/* 34 */ 
INSERT INTO vehicles 
VALUES (
'LI90743R',
2008,
'Maserati',
'Quattroporte',
'Executive GT Automatic',
'Sedan',
16770,
'Y',
'KRA-8632' );

/* 35 */ 
INSERT INTO vehicles 
VALUES (
'NB38489B',
2016,
'Ram',
'1500',
'Tradesman HFE',
'Pickup',
18670,
'Y',
'XBV-0028' );

/* 36 */ 
INSERT INTO vehicles 
VALUES (
'XS81598Y',
2021,
'Hyundai',
'Santa Fe',
'SEL',
'SUV',
28631,
'N',
'NDR-2833' );

/* 37 */ 
INSERT INTO vehicles 
VALUES (
'PC95066A',
2018,
'Alfa Romeo',
'Stelvio',
'Ti',
'SUV',
24203,
'Y',
'ORP-8078' );

/* 38 */ 
INSERT INTO vehicles 
VALUES (
'OW55906T',
2017,
'Acura',
'TLX',
'',
'Sedan',
19782,
'Y',
'ELX-3440' );

/* 39 */ 
INSERT INTO vehicles 
VALUES (
'ZY89039V',
2021,
'Chevrolet',
'Silverado 3500HD',
'Work Truck',
'Pickup',
40197,
'N',
'ZBG-5371' );

/* 40 */ 
INSERT INTO vehicles 
VALUES (
'VF87693M',
2021,
'Toyota',
'C-HR',
'LE',
'SUV',
21499,
'N',
'NGB-4371' );

/* 41 */ 
INSERT INTO vehicles 
VALUES (
'JF82925F',
2017,
'Kia',
'Rio',
'SX',
'Hatchback',
10434,
'Y',
'XSK-7331' );

/* 42 */ 
INSERT INTO vehicles 
VALUES (
'VW90852O',
2017,
'Chevrolet',
'Tahoe',
'LS',
'SUV',
30438,
'Y',
'ZYQ-3802' );

/* 43 */ 
INSERT INTO vehicles 
VALUES (
'MZ43828O',
2018,
'Lexus',
'LX 570',
'Two-Row',
'SUV',
61129,
'Y',
'FTG-3501' );

/* 44 */ 
INSERT INTO vehicles 
VALUES (
'KT56794B',
2019,
'Ford',
'Fusion Energi',
'Titanium',
'Sedan',
22373,
'Y',
'HFO-2503' );

/* 45 */ 
INSERT INTO vehicles 
VALUES (
'SX02048H',
2017,
'Jeep',
'Grand Cherokee',
'Limited 75th Anniversary',
'SUV',
19807,
'Y',
'XCC-7751' );

/* 46 */ 
INSERT INTO vehicles 
VALUES (
'XO72736I',
2020,
'Subaru',
'Outback',
'',
'SUV',
25628,
'Y',
'XVU-1597' );

/* 47 */ 
INSERT INTO vehicles 
VALUES (
'CH81580C',
2020,
'Subaru',
'Impreza',
'',
'Wagon',
18513,
'Y',
'HFO-2503' );

/* 48 */ 
INSERT INTO vehicles 
VALUES (
'OX74270A',
2019,
'Toyota',
'Sequoia',
'TRD Sport',
'SUV',
39001,
'Y',
'XBV-0028' );

/* 49 */ 
INSERT INTO vehicles 
VALUES (
'WW76692R',
2015,
'Lexus',
'RC 350',
'',
'Coupe',
28282,
'Y',
'LAC-2227' );

/* 50 */ 
INSERT INTO vehicles 
VALUES (
'CK37445N',
2016,
'Toyota',
'Camry',
'XSE',
'Sedan',
13905,
'Y',
'FGE-8272' );

/* 51 */ 
INSERT INTO vehicles 
VALUES (
'YC39133Q',
2019,
'Ford',
'F-350 Super Duty',
'XLT',
'Pickup',
38694,
'Y',
'BEI-2297' );

/* 52 */ 
INSERT INTO vehicles 
VALUES (
'IJ64230P',
2018,
'GMC',
'Canyon',
'Denali',
'Pickup',
31649,
'Y',
'LYO-7631' );

/* 53 */ 
INSERT INTO vehicles 
VALUES (
'WD08255R',
2022,
'Kia',
'Sorento',
'S',
'SUV',
32512,
'N',
'ZBG-5371' );

/* 54 */ 
INSERT INTO vehicles 
VALUES (
'EM90489H',
2017,
'Mercedes-Benz',
'Maybach',
'S 600',
'Sedan',
93961,
'Y',
'ZKQ-3411' );

/* 55 */ 
INSERT INTO vehicles 
VALUES (
'BK47490H',
2017,
'Chevrolet',
'Suburban',
'LT',
'SUV',
35099,
'Y',
'MMN-8574' );

/* 56 */ 
INSERT INTO vehicles 
VALUES (
'GE57417N',
2018,
'Dodge',
'Journey',
'SE',
'SUV',
16553,
'Y',
'KRA-8632' );

/* 57 */ 
INSERT INTO vehicles 
VALUES (
'MG36625Q',
2019,
'Cadillac',
'Escalade',
'Luxury',
'SUV',
58163,
'Y',
'OXC-3150' );

/* 58 */ 
INSERT INTO vehicles 
VALUES (
'LW57288K',
2018,
'Nissan',
'LEAF',
'S',
'Hatchback',
13811,
'Y',
'ZKQ-3411' );

/* 59 */ 
INSERT INTO vehicles 
VALUES (
'FT11110D',
2019,
'Cadillac',
'XT4',
'Sport',
'SUV',
31120,
'Y',
'FGE-8272' );

/* 60 */ 
INSERT INTO vehicles 
VALUES (
'JW74578O',
2005,
'Suzuki',
'Aerio',
'SX Fwd',
'Wagon',
605,
'Y',
'JWE-6313' );

/* 61 */ 
INSERT INTO vehicles 
VALUES (
'SB17183Q',
2012,
'Scion',
'tC',
'',
'Coupe',
4703,
'Y',
'YXH-2578' );

/* 62 */ 
INSERT INTO vehicles 
VALUES (
'YZ99840B',
2018,
'Acura',
'MDX',
'Sport Hybrid SH-AWD',
'SUV',
31194,
'Y',
'HFO-2503' );

/* 63 */ 
INSERT INTO vehicles 
VALUES (
'YN14957F',
2020,
'Acura',
'RDX',
'',
'SUV',
29788,
'Y',
'XWS-3018' );

/* 64 */ 
INSERT INTO vehicles 
VALUES (
'AJ97266G',
2018,
'Audi',
'A4',
'2.0 TFSI ultra Premium Plus',
'Sedan',
22306,
'Y',
'NDR-2833' );

/* 65 */ 
INSERT INTO vehicles 
VALUES (
'LC45137B',
2015,
'Volkswagen',
'Beetle',
'1.8T w/Sunroof',
'Hatchback',
12508,
'Y',
'LYO-7631' );

/* 66 */ 
INSERT INTO vehicles 
VALUES (
'OV97267W',
2003,
'Audi',
'TT',
'225hp quattro AWD',
'Convertible',
3239,
'Y',
'SHH-8476' );

/* 67 */ 
INSERT INTO vehicles 
VALUES (
'CH56865K',
2021,
'Subaru',
'Forester',
'Premium',
'SUV',
27170,
'N',
'BEI-2297' );

/* 68 */ 
INSERT INTO vehicles 
VALUES (
'HW49444V',
2016,
'McLaren',
'675LT Spider',
'',
'Coupe',
149201,
'Y',
'ZYQ-3802' );

/* 69 */ 
INSERT INTO vehicles 
VALUES (
'GH64267Z',
2018,
'Toyota',
'C-HR',
'XLE Premium',
'SUV',
18523,
'Y',
'KRA-8632' );

/* 70 */ 
INSERT INTO vehicles 
VALUES (
'XM32771B',
2020,
'Ford',
'Fusion',
'Titanium',
'Sedan',
25987,
'Y',
'JWE-6313' );

/* 71 */ 
INSERT INTO vehicles 
VALUES (
'DQ42877J',
2021,
'Lincoln',
'Navigator',
'L Reserve',
'SUV',
82696,
'N',
'FGE-8272' );

/* 72 */ 
INSERT INTO vehicles 
VALUES (
'LH15451X',
2019,
'Hyundai',
'Accent',
'SE',
'Sedan',
14695,
'Y',
'XBV-0028' );

/* 73 */ 
INSERT INTO vehicles 
VALUES (
'AX34926F',
2021,
'Toyota',
'Avalon',
'TRD',
'Sedan',
39838,
'N',
'ORP-8078' );

/* 74 */ 
INSERT INTO vehicles 
VALUES (
'HQ69903V',
2017,
'Dodge',
'Challenger',
'R/T Shaker',
'Coupe',
21455,
'Y',
'XCC-7751' );

/* 75 */ 
INSERT INTO vehicles 
VALUES (
'WT41325I',
2017,
'BMW',
'M6',
'',
'Convertible',
58831,
'Y',
'MMN-8574' );

/* 76 */ 
INSERT INTO vehicles 
VALUES (
'TT10970K',
2015,
'Ford',
'Focus',
'Titanium',
'Hatchback',
8757,
'Y',
'ZKQ-3411' );

/* 77 */ 
INSERT INTO vehicles 
VALUES (
'FD45148D',
2007,
'Chrysler',
'Crossfire',
'',
'Convertible',
6640,
'Y',
'XWS-3018' );

/* 78 */ 
INSERT INTO vehicles 
VALUES (
'SP79341H',
2009,
'Volvo',
'C70',
'T5',
'Convertible',
2984,
'Y',
'KRA-8632' );

/* 79 */ 
INSERT INTO vehicles 
VALUES (
'FY85428Y',
2018,
'Toyota',
'4Runner',
'SR5',
'SUV',
31315,
'Y',
'ZYQ-3802' );

/* 80 */ 
INSERT INTO vehicles 
VALUES (
'EC85478H',
2011,
'Land Rover',
'LR2',
'',
'SUV',
6254,
'Y',
'XBV-0028' );

/* 81 */ 
INSERT INTO vehicles 
VALUES (
'UV91864Y',
2021,
'Ford',
'F-150',
'Lariat',
'Pickup',
46865,
'N',
'XCC-7751' );

/* 82 */ 
INSERT INTO vehicles 
VALUES (
'JK94795E',
2019,
'Mercedes-Benz',
'E-Class',
'E 450 Sport 4MATIC',
'Wagon',
34944,
'Y',
'ORP-8078' );

/* 83 */ 
INSERT INTO vehicles 
VALUES (
'QF05174H',
2016,
'Toyota',
'Tundra',
'SR5',
'Pickup',
29800,
'Y',
'QPL-3867' );

/* 84 */ 
INSERT INTO vehicles 
VALUES (
'SF55232U',
2018,
'Hyundai',
'Ioniq Electric',
'',
'Hatchback',
15359,
'Y',
'XBV-0028' );

/* 85 */ 
INSERT INTO vehicles 
VALUES (
'LU74225K',
2021,
'Porsche',
'Taycan',
'Turbo',
'Sedan',
137160,
'N',
'MMN-8574' );

/* 86 */ 
INSERT INTO vehicles 
VALUES (
'ZE45906S',
2016,
'Toyota',
'Prius v',
'Five',
'Wagon',
16286,
'Y',
'NDR-2833' );

/* 87 */ 
INSERT INTO vehicles 
VALUES (
'TL71910O',
2001,
'Toyota',
'Camry Solara',
'SE V6',
'Convertible',
1468,
'Y',
'NDR-2833' );

/* 88 */ 
INSERT INTO vehicles 
VALUES (
'UT59292I',
2016,
'Mercedes-Benz',
'Metris',
'Cargo',
'Van/Minivan',
16857,
'Y',
'JWE-6313' );

/* 89 */ 
INSERT INTO vehicles 
VALUES (
'CH91105R',
2001,
'Honda',
'Passport',
'EX 2WD',
'SUV',
923,
'Y',
'ZYQ-3802' );

/* 90 */ 
INSERT INTO vehicles 
VALUES (
'BM85291P',
2018,
'GMC',
'Sierra 3500HD',
'SLE',
'Pickup',
35660,
'Y',
'NDR-2833' );

/* 91 */ 
INSERT INTO vehicles 
VALUES (
'XY36265U',
2016,
'Hyundai',
'Santa Fe Sport',
'2.0T',
'SUV',
16606,
'Y',
'OXC-3150' );

/* 92 */ 
INSERT INTO vehicles 
VALUES (
'XQ52331C',
2018,
'Honda',
'Pilot',
'EX-L',
'SUV',
30487,
'Y',
'ZYQ-3802' );

/* 93 */ 
INSERT INTO vehicles 
VALUES (
'JG61759T',
2019,
'GMC',
'Terrain',
'SLE',
'SUV',
22909,
'Y',
'XBV-0028' );

/* 94 */ 
INSERT INTO vehicles 
VALUES (
'JP77416F',
2019,
'Volkswagen',
'Golf SportWagen',
'1.4T SE',
'Wagon',
23347,
'Y',
'XCC-7751' );

/* 95 */ 
INSERT INTO vehicles 
VALUES (
'KJ58594Q',
2016,
'Cadillac',
'XTS',
'Premium',
'Sedan',
22343,
'Y',
'ZBG-5371' );

/* 96 */ 
INSERT INTO vehicles 
VALUES (
'GE40588R',
2019,
'Ford',
'Explorer',
'',
'SUV',
23965,
'Y',
'SHH-8476' );

/* 97 */ 
INSERT INTO vehicles 
VALUES (
'RW98572S',
2019,
'Lexus',
'UX 200',
'Luxury',
'SUV',
27130,
'Y',
'FGE-8272' );

/* 98 */ 
INSERT INTO vehicles 
VALUES (
'KE54510P',
2017,
'Toyota',
'Yaris',
'SE',
'Hatchback',
14392,
'Y',
'NDR-2833' );

/* 99 */ 
INSERT INTO vehicles 
VALUES (
'AN18157Y',
2018,
'BMW',
'X6',
'sDrive35i',
'SUV',
41224,
'Y',
'BEI-2297' );

/* 100 */ 
INSERT INTO vehicles 
VALUES (
'QC81677G',
2016,
'Maserati',
'GranTurismo',
'MC Centennial',
'Coupe',
48071,
'Y',
'XBV-0028' );

/* 101 */ 
INSERT INTO vehicles 
VALUES (
'BY84318H',
2020,
'Mercedes-Benz',
'GLS-Class',
'GLS 450 4MATIC',
'SUV',
55638,
'Y',
'ZKQ-3411' );

/* 102 */ 
INSERT INTO vehicles 
VALUES (
'HX71589F',
2019,
'Volvo',
'XC60',
'T8 R-Design Twin Engine Plug-In Hybrid',
'SUV',
43880,
'Y',
'HFO-2503' );

/* 103 */ 
INSERT INTO vehicles 
VALUES (
'ZT37666U',
2010,
'Lexus',
'RX 350',
'',
'SUV',
7862,
'Y',
'QPL-3867' );

/* 104 */ 
INSERT INTO vehicles 
VALUES (
'SD54602J',
2018,
'INFINITI',
'QX60',
'',
'SUV',
24404,
'Y',
'ZKQ-3411' );

/* 105 */ 
INSERT INTO vehicles 
VALUES (
'ZF00857R',
2017,
'Cadillac',
'XT5',
'Platinum',
'SUV',
32866,
'Y',
'ELX-3440' );

/* 106 */ 
INSERT INTO vehicles 
VALUES (
'HZ24837G',
2019,
'GMC',
'Yukon',
'SLT',
'SUV',
42162,
'Y',
'ELX-3440' );

/* 107 */ 
INSERT INTO vehicles 
VALUES (
'QN79266G',
2018,
'Cadillac',
'CTS',
'',
'Sedan',
21436,
'Y',
'ELX-3440' );

/* 108 */ 
INSERT INTO vehicles 
VALUES (
'FJ52187U',
2015,
'Volkswagen',
'CC',
'R-Line PZEV',
'Sedan',
13575,
'Y',
'XBV-0028' );

/* 109 */ 
INSERT INTO vehicles 
VALUES (
'JR48166I',
2019,
'MINI',
'Hardtop 4 Door',
'Cooper S',
'Hatchback',
20996,
'Y',
'NGB-4371' );

/* 110 */ 
INSERT INTO vehicles 
VALUES (
'AQ02021E',
2019,
'Acura',
'NSX',
'',
'Coupe',
109882,
'Y',
'HFO-2503' );

/* 111 */ 
INSERT INTO vehicles 
VALUES (
'OL22009W',
2019,
'BMW',
'4 Series Gran Coupe',
'440i xDrive',
'Coupe',
31907,
'Y',
'JWE-6313' );

/* 112 */ 
INSERT INTO vehicles 
VALUES (
'FM28311U',
2019,
'Chevrolet',
'Silverado 1500 LD',
'Z71 LT',
'Pickup',
30978,
'Y',
'ORP-8078' );

/* 113 */ 
INSERT INTO vehicles 
VALUES (
'NZ35374U',
2019,
'Nissan',
'NV Cargo',
'2500 S',
'Van/Minivan',
33191,
'Y',
'ELX-3440' );

/* 114 */ 
INSERT INTO vehicles 
VALUES (
'DQ84962N',
2019,
'Porsche',
'Macan',
'S',
'SUV',
42386,
'Y',
'NDR-2833' );

/* 115 */ 
INSERT INTO vehicles 
VALUES (
'OH60090I',
2015,
'Nissan',
'Titan',
'SL',
'Pickup',
25701,
'Y',
'JWE-6313' );

/* 116 */ 
INSERT INTO vehicles 
VALUES (
'GX68343C',
2015,
'Volvo',
'S60',
'T5',
'Sedan',
12304,
'Y',
'YXH-2578' );

/* 117 */ 
INSERT INTO vehicles 
VALUES (
'HY02279D',
2017,
'Acura',
'RDX',
'Technology and AcuraWatch Plus Package',
'SUV',
24873,
'Y',
'KRA-8632' );

/* 118 */ 
INSERT INTO vehicles 
VALUES (
'WQ09494M',
2006,
'Jaguar',
'X-Type',
'3.0L Sportwagon',
'Sedan',
3401,
'Y',
'FTG-3501' );

/* 119 */ 
INSERT INTO vehicles 
VALUES (
'XK87963O',
2017,
'Dodge',
'Challenger',
'R/T Shaker',
'Coupe',
24979,
'Y',
'KRA-8632' );

/* 120 */ 
INSERT INTO vehicles 
VALUES (
'EG32649W',
2019,
'Nissan',
'Titan',
'S',
'Pickup',
28144,
'Y',
'NDR-2833' );

/* 121 */ 
INSERT INTO vehicles 
VALUES (
'PY34197W',
2019,
'Chevrolet',
'Silverado 3500HD',
'LT',
'Pickup',
43510,
'Y',
'JWE-6313' );

/* 122 */ 
INSERT INTO vehicles 
VALUES (
'FV91120U',
2000,
'Dodge',
'Dakota',
'',
'Pickup',
860,
'Y',
'JWE-6313' );

/* 123 */ 
INSERT INTO vehicles 
VALUES (
'WH33257U',
2015,
'Subaru',
'WRX',
'STI',
'Sedan',
20090,
'Y',
'NDR-2833' );

/* 124 */ 
INSERT INTO vehicles 
VALUES (
'QQ29549S',
2018,
'Bentley',
'Mulsanne',
'Speed',
'Sedan',
128290,
'Y',
'ZKQ-3411' );

/* 125 */ 
INSERT INTO vehicles 
VALUES (
'NX29208P',
2016,
'Audi',
'allroad',
'Premium quattro',
'Wagon',
17673,
'Y',
'KRA-8632' );

/* 126 */ 
INSERT INTO vehicles 
VALUES (
'GN59319K',
2019,
'BMW',
'X7',
'xDrive40i',
'SUV',
59792,
'Y',
'NDR-2833' );

/* 127 */ 
INSERT INTO vehicles 
VALUES (
'KD17885Q',
2015,
'Subaru',
'Forester',
'2.0XT Touring',
'SUV',
16659,
'Y',
'YXH-2578' );

/* 128 */ 
INSERT INTO vehicles 
VALUES (
'CB63712T',
2019,
'GMC',
'Sierra 2500HD',
'',
'Pickup',
43474,
'Y',
'ELX-3440' );

/* 129 */ 
INSERT INTO vehicles 
VALUES (
'KW61365N',
2016,
'Hyundai',
'Tucson',
'Sport',
'SUV',
13267,
'Y',
'XCC-7751' );

/* 130 */ 
INSERT INTO vehicles 
VALUES (
'SL83677G',
2017,
'Chevrolet',
'Camaro',
'2LT',
'Coupe',
20574,
'Y',
'FGE-8272' );

/* 131 */ 
INSERT INTO vehicles 
VALUES (
'WV38739I',
2015,
'Mercedes-Benz',
'CLA-Class',
'CLA 45 AMG',
'Sedan',
17874,
'Y',
'FTG-3501' );

/* 132 */ 
INSERT INTO vehicles 
VALUES (
'NW62349P',
2018,
'McLaren',
'570GT',
'',
'Coupe',
145423,
'Y',
'XVU-1597' );

/* 133 */ 
INSERT INTO vehicles 
VALUES (
'TR16326G',
2016,
'Honda',
'Civic',
'Touring',
'Sedan',
18797,
'Y',
'XWS-3018' );

/* 134 */ 
INSERT INTO vehicles 
VALUES (
'IB31020Q',
2017,
'MINI',
'Clubman',
'Cooper S',
'Hatchback',
17219,
'Y',
'ORP-8078' );

/* 135 */ 
INSERT INTO vehicles 
VALUES (
'LG60554I',
2020,
'INFINITI',
'Q50',
'3.0t SPORT',
'Sedan',
33214,
'Y',
'ELX-3440' );

/* 136 */ 
INSERT INTO vehicles 
VALUES (
'BS55936Z',
2019,
'Subaru',
'BRZ',
'Limited',
'Coupe',
22123,
'Y',
'ZYQ-3802' );

/* 137 */ 
INSERT INTO vehicles 
VALUES (
'GF40058A',
2015,
'BMW',
'7 Series',
'750Li',
'Sedan',
25854,
'Y',
'FGE-8272' );

/* 138 */ 
INSERT INTO vehicles 
VALUES (
'IW35161U',
2018,
'Land Rover',
'Range Rover',
'Autobiography',
'SUV',
79463,
'Y',
'XSK-7331' );

