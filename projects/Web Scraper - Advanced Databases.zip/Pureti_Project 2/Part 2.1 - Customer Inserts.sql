/* 1 */ 
INSERT INTO customers (sale_id, VIN, customer_id, salesperson_id, vehicle_status, sale_date, mileage, sale_price) 
VALUES (
'281320',
'Royce',
'Vallée',
'',
'1691 School Street',
'Washington',
'DC',
20036 );

/* 2 */ 
INSERT INTO customers 
VALUES (
'279708',
'Lavon',
'McNamara',
'L',
'4046 Biddie Lane',
'Richmond',
'VA',
23219 );

/* 3 */ 
INSERT INTO customers 
VALUES (
'278355',
'Dennis',
'Krause',
'',
'537 Melody Lane',
'Glen Allen',
'VA',
23060 );

/* 4 */ 
INSERT INTO customers 
VALUES (
'280748',
'Taisa',
'Timayev',
'',
'2236 Passaic Street',
'Washington',
'DC',
20007 );

/* 5 */ 
INSERT INTO customers 
VALUES (
'284435',
'Emilia',
'Wilson',
'',
'3656 Rhode Island Avenue',
'Washington',
'DC',
20007 );

/* 6 */ 
INSERT INTO customers 
VALUES (
'274078',
'Perry',
'Sanderson',
'B',
'2551 Goldcliff Circle',
'Washington',
'DC',
20002 );

/* 7 */ 
INSERT INTO customers 
VALUES (
'284131',
'Mustafa',
'Abraham',
'',
'2253 Pine Tree Lane',
'Mount Airy',
'MD',
21771 );

/* 8 */ 
INSERT INTO customers 
VALUES (
'280997',
'Susanne',
'Schwarz',
'',
'4427 Passaic Street',
'Washington',
'DC',
20007 );

/* 9 */ 
INSERT INTO customers 
VALUES (
'281457',
'Haide',
'Duarte',
'M',
'87 Hickory Lane',
'Washington',
'DC',
20007 );

/* 10 */ 
INSERT INTO customers 
VALUES (
'277949',
'Ellie',
'Wilmot',
'',
'3877 Lake Floyd Circle',
'Frederick',
'MD',
21703 );

/* 11 */ 
INSERT INTO customers 
VALUES (
'278488',
'Marie',
'Mortensen',
'J',
'60 School Street',
'Washington',
'DC',
20017 );

/* 12 */ 
INSERT INTO customers 
VALUES (
'283081',
'Hajjaj',
'Awad',
'Z',
'3650 Massachusetts Avenue',
'Washington',
'DC',
20011 );

/* 13 */ 
INSERT INTO customers 
VALUES (
'273992',
'Jana',
'Kovač',
'',
'3596 Harron Drive',
'Columbia',
'MD',
21046 );

/* 14 */ 
INSERT INTO customers 
VALUES (
'286268',
'Martin',
'Petersen',
'',
'3302 Beechwood Drive',
'Crisfield',
'MD',
21817 );

/* 15 */ 
INSERT INTO customers 
VALUES (
'283351',
'Duccio',
'Pinto',
'',
'4639 Bobcat Drive',
'Washington',
'MD',
20200 );

/* 16 */ 
INSERT INTO customers 
VALUES (
'278463',
'Donald',
'Larrabee',
'M',
'4255 Goldcliff Circle',
'Washington',
'DC',
20005 );

/* 17 */ 
INSERT INTO customers 
VALUES (
'279323',
'Lengyel',
'Ábel',
'',
'1960 Kildeer Drive',
'Norfolk',
'VA',
23502 );

/* 18 */ 
INSERT INTO customers 
VALUES (
'274830',
'Alexander',
'Ibrahim',
'',
'2083 Melody Lane',
'Richmond',
'VA',
23220 );

/* 19 */ 
INSERT INTO customers 
VALUES (
'284989',
'Claire',
'McIntosh',
'',
'3152 Jefferson Street',
'Fredericksburg',
'VA',
22401 );

/* 20 */ 
INSERT INTO customers 
VALUES (
'286326',
'Tina',
'Turner',
'',
'1771 Payne Street',
'Cana',
'VA',
24317 );

/* 21 */ 
INSERT INTO customers 
VALUES (
'287314',
'Alana',
'Allport',
'',
'3265 Rhode Island Avenue',
'Washington',
'DC',
20036 );

/* 22 */ 
INSERT INTO customers 
VALUES (
'277482',
'Berhane',
'Kifle',
'',
'383 Rhode Island Avenue',
'Herndon',
'DC',
22070 );

/* 23 */ 
INSERT INTO customers 
VALUES (
'286574',
'Medhanie',
'Efrem',
'',
'2972 Broadcast Drive',
'Reston',
'VA',
22091 );

/* 24 */ 
INSERT INTO customers 
VALUES (
'283978',
'Rhoda',
'Gardner',
'',
'2365 Green Gate Lane',
'Baltimore',
'MD',
21202 );

/* 25 */ 
INSERT INTO customers 
VALUES (
'278578',
'Vilma',
'Nilsson',
'',
'4150 Payne Street',
'Sylvatus',
'VA',
24343 );

/* 26 */ 
INSERT INTO customers 
VALUES (
'283807',
'Ida',
'Lauridsen',
'E',
'1356 Hickory Lane',
'Silver Spring',
'DC',
20904 );

/* 27 */ 
INSERT INTO customers 
VALUES (
'282847',
'Alberte',
'Karlsen',
'M',
'3402 Passaic Street',
'Washington',
'DC',
20036 );

/* 28 */ 
INSERT INTO customers 
VALUES (
'287101',
'Ksenija',
'Hrvat',
'',
'573 Hickory Lane',
'Beltsville',
'DC',
20705 );

/* 29 */ 
INSERT INTO customers 
VALUES (
'273855',
'Marco',
'Maurer',
'',
'126 Rhode Island Avenue',
'Washington',
'DC',
20005 );

/* 30 */ 
INSERT INTO customers 
VALUES (
'281027',
'Beatrice',
'Araujo',
'S',
'2937 Doe Meadow Drive',
'Silver Spring',
'MD',
20906 );

/* 31 */ 
INSERT INTO customers 
VALUES (
'273784',
'Trương',
'Trương',
'',
'2478 Hickory Lane',
'Washington',
'DC',
20005 );

/* 32 */ 
INSERT INTO customers 
VALUES (
'274372',
'Caspian',
'Lindholm',
'',
'2261 Massachusetts Avenue',
'Washington',
'DC',
20011 );

/* 33 */ 
INSERT INTO customers 
VALUES (
'279196',
'Mariya',
'Kakuta',
'',
'4725 Worley Avenue',
'South Boston',
'VA',
24592 );

/* 34 */ 
INSERT INTO customers 
VALUES (
'286430',
'Atyaf',
'Touma',
'M',
'1825 Allison Avenue',
'Norfolk',
'VA',
23510 );

/* 35 */ 
INSERT INTO customers 
VALUES (
'281049',
'Geoffrey',
'Ferland',
'',
'2 Passaic Street',
'Washington',
'DC',
20036 );

/* 36 */ 
INSERT INTO customers 
VALUES (
'280702',
'Patricija',
'Nikolić',
'',
'1659 White Pine Lane',
'Winchester',
'VA',
22601 );

/* 37 */ 
INSERT INTO customers 
VALUES (
'283823',
'Lida',
'Čerče',
'',
'822 Blue Spruce Lane',
'Windsor Mill',
'MD',
21244 );

/* 38 */ 
INSERT INTO customers 
VALUES (
'278819',
'Chukwubuikem',
'Chifo',
'',
'2578 Pine Tree Lane',
'Laurel',
'MD',
20707 );

/* 39 */ 
INSERT INTO customers 
VALUES (
'274127',
'Italina',
'Valentín',
'J',
'1944 Northwest Boulevard',
'Washington',
'DC',
20032 );

/* 40 */ 
INSERT INTO customers 
VALUES (
'283449',
'Isabella',
'Thatcher',
'',
'1550 Broadcast Drive',
'Arlington',
'VA',
22201 );

/* 41 */ 
INSERT INTO customers 
VALUES (
'280667',
'Jasper',
'Bannan',
'',
'405 Bobcat Drive',
'Washington',
'MD',
20008 );

/* 42 */ 
INSERT INTO customers 
VALUES (
'273928',
'Chidinma',
'Amadi',
'',
'3564 Northwest Boulevard',
'Savage',
'DC',
20763 );

/* 43 */ 
INSERT INTO customers 
VALUES (
'282900',
'Demet',
'Koenderink',
'',
'669 Doe Meadow Drive',
'Washington',
'MD',
20005 );

/* 44 */ 
INSERT INTO customers 
VALUES (
'282571',
'Iida',
'Hahli',
'',
'2459 Blue Spruce Lane',
'Baltimore',
'MD',
21218 );

/* 45 */ 
INSERT INTO customers 
VALUES (
'284858',
'Robel',
'Iggi',
'',
'3694 Green Gate Lane',
'Baltimore',
'MD',
21202 );

/* 46 */ 
INSERT INTO customers 
VALUES (
'282262',
'Freja',
'Lundberg',
'',
'4479 Northwest Boulevard',
'Savage',
'DC',
20763 );

/* 47 */ 
INSERT INTO customers 
VALUES (
'281219',
'Karp',
'Volkov',
'',
'2533 Forest Drive',
'Chantilly',
'VA',
22021 );

/* 48 */ 
INSERT INTO customers 
VALUES (
'285069',
'莊宜庭',
'莊宜庭',
'',
'557 Wilmar Farm Road',
'Frederick',
'MD',
21701 );

/* 49 */ 
INSERT INTO customers 
VALUES (
'274799',
'Rowan',
'Roper',
'',
'3689 Biddie Lane',
'Richmond',
'VA',
23223 );

/* 50 */ 
INSERT INTO customers 
VALUES (
'284135',
'Amadeus',
'Lindberg',
'',
'1159 Golf Course Drive',
'Chantilly',
'VA',
22021 );

/* 51 */ 
INSERT INTO customers 
VALUES (
'285223',
'Isobel',
'Hughes',
'',
'3474 Daffodil Lane',
'Fairfax',
'VA',
22032 );

/* 52 */ 
INSERT INTO customers 
VALUES (
'287149',
'Almaz',
'Futsum',
'',
'4601 Hewes Avenue',
'Baltimore',
'MD',
21202 );

/* 53 */ 
INSERT INTO customers 
VALUES (
'273921',
'Patrick',
'Gray',
'V',
'4344 Golf Course Drive',
'Washington',
'VA',
20005 );

/* 54 */ 
INSERT INTO customers 
VALUES (
'279614',
'Harley',
'Heath',
'',
'4835 Pinchelone Street',
'Virginia Beach',
'VA',
23464 );

/* 55 */ 
INSERT INTO customers 
VALUES (
'282884',
'Ashleigh',
'Munro',
'',
'439 Hickory Lane',
'Beltsville',
'DC',
20705 );

/* 56 */ 
INSERT INTO customers 
VALUES (
'281292',
'Lars',
'Josefsen',
'',
'2455 Bluff Street',
'Smithsburg',
'MD',
21783 );

/* 57 */ 
INSERT INTO customers 
VALUES (
'277683',
'Karen',
'Andersen',
'',
'3704 Calvin Street',
'Baltimore',
'MD',
21202 );

/* 58 */ 
INSERT INTO customers 
VALUES (
'281196',
'Karla',
'Lassen',
'V',
'4143 Beechwood Drive',
'Clarksville',
'MD',
21029 );

/* 59 */ 
INSERT INTO customers 
VALUES (
'285992',
'Jona',
'Puščenik',
'',
'858 Conference Center Way',
'Washington',
'VA',
20005 );

/* 60 */ 
INSERT INTO customers 
VALUES (
'283407',
'Zada',
'Budimović',
'',
'3490 Nelm Street',
'Mclean',
'VA',
22101 );

/* 61 */ 
INSERT INTO customers 
VALUES (
'274243',
'Juliusz',
'Adamski',
'',
'4983 Worley Avenue',
'Charlottesville',
'VA',
22903 );

/* 62 */ 
INSERT INTO customers 
VALUES (
'277271',
'Jay',
'Black',
'',
'502 Roane Avenue',
'Beltsville',
'MD',
20705 );

/* 63 */ 
INSERT INTO customers 
VALUES (
'275080',
'Ovlur',
'Shervashidze',
'',
'4748 Chatham Way',
'Reston',
'MD',
22091 );

/* 64 */ 
INSERT INTO customers 
VALUES (
'284311',
'Vsevolod',
'Baryshnikov',
'',
'4018 Broadcast Drive',
'Washington',
'VA',
20011 );

/* 65 */ 
INSERT INTO customers 
VALUES (
'277123',
'Paine',
'Cardona',
'C',
'4661 Hickory Lane',
'Washington',
'DC',
20005 );

/* 66 */ 
INSERT INTO customers 
VALUES (
'281391',
'Olava',
'Rognstad',
'',
'1863 Hamilton Drive',
'Woodlawn',
'MD',
21207 );

/* 67 */ 
INSERT INTO customers 
VALUES (
'278025',
'Mitchell',
'Perrigo',
'E',
'1987 Hurry Street',
'Harrisonburg',
'VA',
22801 );

/* 68 */ 
INSERT INTO customers 
VALUES (
'278051',
'Nnamutaezinwa',
'Chukwujekwu',
'',
'4786 Pinchelone Street',
'Portsmouth',
'VA',
23707 );

/* 69 */ 
INSERT INTO customers 
VALUES (
'274749',
'Shelby',
'Cameron',
'',
'4619 Hamilton Drive',
'Easton',
'MD',
21601 );

/* 70 */ 
INSERT INTO customers 
VALUES (
'285949',
'Frederik',
'Mortensen',
'C',
'1819 Ashford Drive',
'Mclean',
'VA',
22101 );

/* 71 */ 
INSERT INTO customers 
VALUES (
'283935',
'Weronika',
'Zawadzka',
'',
'1554 Harron Drive',
'Hanover',
'MD',
21076 );

/* 72 */ 
INSERT INTO customers 
VALUES (
'278339',
'Drugi',
'Maciejewski',
'',
'2196 Nelm Street',
'Lanham',
'VA',
20706 );

/* 73 */ 
INSERT INTO customers 
VALUES (
'273692',
'Kamila',
'Korgay',
'',
'1767 Columbia Boulevard',
'Elkridge',
'MD',
21227 );

/* 74 */ 
INSERT INTO customers 
VALUES (
'283463',
'Katrene',
'Qarmduct',
'',
'4408 Doe Meadow Drive',
'Baltimore',
'MD',
21202 );

/* 75 */ 
INSERT INTO customers 
VALUES (
'276828',
'Karolin',
'Konig',
'',
'2779 Passaic Street',
'Washington',
'DC',
20036 );

/* 76 */ 
INSERT INTO customers 
VALUES (
'284061',
'Ijenuwa',
'Oguejiofor',
'',
'2942 Hewes Avenue',
'Hanover',
'MD',
21076 );

/* 77 */ 
INSERT INTO customers 
VALUES (
'280381',
'Michelle',
'Jamieson',
'',
'2835 Lawman Avenue',
'Reston',
'VA',
22070 );

/* 78 */ 
INSERT INTO customers 
VALUES (
'281818',
'Dagur',
'Valgeirsson',
'',
'139 School Street',
'Washington',
'DC',
20036 );

/* 79 */ 
INSERT INTO customers 
VALUES (
'283310',
'Siham',
'Roelse',
'',
'4652 Goldcliff Circle',
'Washington',
'DC',
20005 );

/* 80 */ 
INSERT INTO customers 
VALUES (
'274732',
'Chinwenma',
'Nnamdi',
'',
'3401 Daffodil Lane',
'Reston',
'VA',
22090 );

/* 81 */ 
INSERT INTO customers 
VALUES (
'279699',
'Danait',
'Kifle',
'',
'3623 Goldcliff Circle',
'Washington',
'DC',
20011 );

/* 82 */ 
INSERT INTO customers 
VALUES (
'283357',
'Tayma''',
'Khoury',
'L',
'4638 Adams Avenue',
'Washington',
'MD',
20004 );

/* 83 */ 
INSERT INTO customers 
VALUES (
'280661',
'Trine',
'Villadsen',
'V',
'1544 Forest Drive',
'Arlington',
'VA',
22204 );

/* 84 */ 
INSERT INTO customers 
VALUES (
'273892',
'Ayub',
'Barsukov',
'',
'1244 Flanigan Oaks Drive',
'Silver Spring',
'MD',
20904 );

/* 85 */ 
INSERT INTO customers 
VALUES (
'278114',
'Semira',
'Tekle',
'',
'4228 Forest Drive',
'Arlington',
'VA',
22201 );

/* 86 */ 
INSERT INTO customers 
VALUES (
'274550',
'Katrin',
'Puffelen',
'v',
'1466 Fleming Way',
'Richmond',
'VA',
23222 );

/* 87 */ 
INSERT INTO customers 
VALUES (
'287032',
'Ifeanacho',
'Nkemjika',
'',
'2380 Goldcliff Circle',
'Washington',
'DC',
20005 );

/* 88 */ 
INSERT INTO customers 
VALUES (
'286252',
'Alda',
'Sigtryggsdóttir',
'',
'1392 Passaic Street',
'Washington',
'DC',
20036 );

/* 89 */ 
INSERT INTO customers 
VALUES (
'287304',
'Nghiêm',
'Nghiêm',
'',
'819 Calvin Street',
'Hanover',
'MD',
21076 );

/* 90 */ 
INSERT INTO customers 
VALUES (
'280524',
'Innocent',
'Abramowitz',
'',
'1315 School Street',
'Washington',
'DC',
20005 );

/* 91 */ 
INSERT INTO customers 
VALUES (
'282594',
'Chino',
'Sekiguchi',
'',
'4586 Massachusetts Avenue',
'Washington',
'DC',
20024 );

/* 92 */ 
INSERT INTO customers 
VALUES (
'277819',
'Oscar',
'Milanesi',
'',
'4956 Cambridge Place',
'Towson',
'MD',
21204 );

/* 93 */ 
INSERT INTO customers 
VALUES (
'286324',
'Merimac',
'Took-Took',
'',
'1117 Fleming Way',
'Richmond',
'VA',
23219 );

/* 94 */ 
INSERT INTO customers 
VALUES (
'280576',
'Angelica',
'Hegwood',
'',
'1206 Goldcliff Circle',
'Washington',
'DC',
20036 );

/* 95 */ 
INSERT INTO customers 
VALUES (
'287409',
'Leon',
'Sundnes',
'',
'4546 Forest Drive',
'Washington',
'VA',
20005 );

/* 96 */ 
INSERT INTO customers 
VALUES (
'279281',
'Milo',
'Crawford',
'',
'4579 Rhode Island Avenue',
'Washington',
'DC',
20036 );

/* 97 */ 
INSERT INTO customers 
VALUES (
'273625',
'Kristine',
'Egede',
'',
'2163 Massachusetts Avenue',
'Washington',
'DC',
20011 );

/* 98 */ 
INSERT INTO customers 
VALUES (
'281712',
'Ubalda',
'Lombardi',
'',
'1503 North Street',
'Lynchburg',
'VA',
24501 );

/* 99 */ 
INSERT INTO customers 
VALUES (
'279141',
'Ekechukwu',
'Elechi',
'',
'4703 Rhode Island Avenue',
'Washington',
'DC',
20005 );

/* 100 */ 
INSERT INTO customers 
VALUES (
'286344',
'Rhian',
'Donaldson',
'',
'405 Golf Course Drive',
'Alexandria',
'VA',
22303 );

/* 101 */ 
INSERT INTO customers 
VALUES (
'282687',
'Khavazh',
'Karataev',
'',
'4830 Marie Street',
'Columbia',
'MD',
21044 );

/* 102 */ 
INSERT INTO customers 
VALUES (
'281386',
'La',
'Cao',
'T',
'1176 Beechwood Drive',
'Laurel',
'MD',
20707 );

/* 103 */ 
INSERT INTO customers 
VALUES (
'277085',
'Marsha',
'Nelson',
'B',
'1103 Goldcliff Circle',
'Washington',
'DC',
20005 );

/* 104 */ 
INSERT INTO customers 
VALUES (
'274103',
'Kadi',
'Kallatar',
'',
'3200 Flanigan Oaks Drive',
'Landover',
'MD',
20785 );

/* 105 */ 
INSERT INTO customers 
VALUES (
'278200',
'Baranyi',
'Elizabet',
'',
'4358 Meadowview Drive',
'Culpeper',
'VA',
22701 );

/* 106 */ 
INSERT INTO customers 
VALUES (
'282265',
'Veselko',
'Jurišić',
'',
'4872 Massachusetts Avenue',
'Washington',
'DC',
20005 );

/* 107 */ 
INSERT INTO customers 
VALUES (
'277378',
'Jiao',
'Ch''ang',
'',
'1078 Harron Drive',
'Baltimore',
'MD',
21201 );

/* 108 */ 
INSERT INTO customers 
VALUES (
'273940',
'Niels',
'Hansen',
'',
'3134 Five Points',
'Easton',
'MD',
21601 );

/* 109 */ 
INSERT INTO customers 
VALUES (
'275992',
'Sydney',
'Summers',
'T',
'246 Pinchelone Street',
'Norfolk',
'VA',
23502 );

/* 110 */ 
INSERT INTO customers 
VALUES (
'283091',
'Cornelis',
'Björk',
'',
'4641 Columbia Boulevard',
'Baltimore',
'MD',
21229 );

/* 111 */ 
INSERT INTO customers 
VALUES (
'273864',
'Ishin',
'Kanou',
'',
'3050 Goldcliff Circle',
'Washington',
'DC',
20002 );

/* 112 */ 
INSERT INTO customers 
VALUES (
'281946',
'Giuseppina',
'Arcuri',
'',
'554 Murry Street',
'Portsmouth',
'VA',
23707 );

/* 113 */ 
INSERT INTO customers 
VALUES (
'279484',
'Kintata',
'D''jon',
'',
'304 Flanigan Oaks Drive',
'Bethesda',
'MD',
20014 );

/* 114 */ 
INSERT INTO customers 
VALUES (
'285312',
'Kezhke',
'SepIch',
'',
'632 Green Gate Lane',
'Baltimore',
'MD',
21202 );

/* 115 */ 
INSERT INTO customers 
VALUES (
'281089',
'Dodinas',
'Goold',
'',
'4514 Columbia Boulevard',
'Ellicott City',
'MD',
21042 );

/* 116 */ 
INSERT INTO customers 
VALUES (
'277011',
'Apolinar',
'Roldán',
'H',
'3175 Wilmar Farm Road',
'Washington',
'MD',
20200 );

/* 117 */ 
INSERT INTO customers 
VALUES (
'274712',
'Torben',
'Jessen',
'A',
'3893 Goldcliff Circle',
'Washington',
'DC',
20005 );

/* 118 */ 
INSERT INTO customers 
VALUES (
'280706',
'Sienna',
'Simpson',
'',
'1337 Eden Drive',
'Richmond',
'VA',
23228 );

/* 119 */ 
INSERT INTO customers 
VALUES (
'285585',
'Zdenek',
'Patry',
'',
'3259 Douglas Dairy Road',
'Duffield',
'VA',
24244 );

/* 120 */ 
INSERT INTO customers 
VALUES (
'281356',
'Fosco',
'Romani',
'',
'2851 Hickory Lane',
'Washington',
'DC',
20008 );

/* 121 */ 
INSERT INTO customers 
VALUES (
'285400',
'Somadina',
'Onwuemelie',
'',
'2616 Passaic Street',
'Washington',
'DC',
20005 );

/* 122 */ 
INSERT INTO customers 
VALUES (
'286854',
'Kaja',
'Vilhjálmsdóttir',
'',
'52 Rhode Island Avenue',
'Chantilly',
'DC',
20151 );

/* 123 */ 
INSERT INTO customers 
VALUES (
'275695',
'Ugonnatubelum',
'Chinagorom',
'',
'1498 Columbia Boulevard',
'Baltimore',
'MD',
21202 );

/* 124 */ 
INSERT INTO customers 
VALUES (
'280431',
'Milan',
'Šorm',
'',
'86 Hickory Lane',
'Washington',
'DC',
20009 );

/* 125 */ 
INSERT INTO customers 
VALUES (
'285778',
'Sesuna',
'Aman',
'',
'1257 Hickory Heights Drive',
'Baltimore',
'MD',
21206 );

/* 126 */ 
INSERT INTO customers 
VALUES (
'282304',
'Fumiyo',
'Hidaka',
'',
'4244 Broadcast Drive',
'Mc Lean',
'VA',
22102 );

/* 127 */ 
INSERT INTO customers 
VALUES (
'274023',
'Syed',
'Paterson',
'',
'1644 Coulter Lane',
'Warsaw',
'VA',
22572 );

/* 128 */ 
INSERT INTO customers 
VALUES (
'283030',
'Herugar',
'Brandagamba',
'',
'4998 Columbia Boulevard',
'Darlington',
'MD',
21034 );

/* 129 */ 
INSERT INTO customers 
VALUES (
'284029',
'Nkemdirim',
'Onyeoruru',
'',
'4425 Goldcliff Circle',
'Washington',
'DC',
20019 );

/* 130 */ 
INSERT INTO customers 
VALUES (
'286363',
'Maura',
'Pisani',
'',
'1599 Massachusetts Avenue',
'Washington',
'DC',
20020 );

/* 131 */ 
INSERT INTO customers 
VALUES (
'278102',
'Vitalia',
'Adame',
'T',
'3068 Rhode Island Avenue',
'Washington',
'DC',
20004 );

/* 132 */ 
INSERT INTO customers 
VALUES (
'276963',
'Luka',
'Uvarek',
'',
'4302 Hamilton Drive',
'Baltimore',
'MD',
21229 );

/* 133 */ 
INSERT INTO customers 
VALUES (
'280049',
'Ijendu',
'Yobanna',
'',
'78 Hickory Lane',
'Vienna',
'DC',
22182 );

/* 134 */ 
INSERT INTO customers 
VALUES (
'277957',
'Lily',
'Parkinson',
'',
'1654 Daffodil Lane',
'Alexandria',
'VA',
22303 );

/* 135 */ 
INSERT INTO customers 
VALUES (
'275591',
'Melita',
'Lučev',
'',
'2907 Columbia Boulevard',
'Bel Air',
'MD',
21014 );

/* 136 */ 
INSERT INTO customers 
VALUES (
'287281',
'T''Mira',
'Caxel',
'',
'3910 Massachusetts Avenue',
'Washington',
'DC',
20200 );

/* 137 */ 
INSERT INTO customers 
VALUES (
'281767',
'Eshan',
'Johnstone',
'',
'2899 Cabell Avenue',
'Arlington',
'VA',
22201 );

/* 138 */ 
INSERT INTO customers 
VALUES (
'277395',
'Karl',
'Petrussen',
'',
'1560 Brooklyn Street',
'Craigsville',
'VA',
24430 );

/* 139 */ 
INSERT INTO customers 
VALUES (
'280550',
'Kenzo',
'Hoshino',
'',
'1401 Chatham Way',
'Reston',
'MD',
22091 );

/* 140 */ 
INSERT INTO customers 
VALUES (
'280685',
'Kenya',
'Akita',
'',
'1364 Shady Pines Drive',
'Galax',
'VA',
24333 );

/* 141 */ 
INSERT INTO customers 
VALUES (
'284682',
'Konstantyn',
'Duda',
'',
'3080 Massachusetts Avenue',
'Washington',
'DC',
20002 );

/* 142 */ 
INSERT INTO customers 
VALUES (
'280567',
'Aina',
'Johnsson',
'',
'1531 Hamilton Drive',
'Towson',
'MD',
21204 );

/* 143 */ 
INSERT INTO customers 
VALUES (
'279677',
'Herczegh',
'Ninacska',
'',
'4081 Hickory Lane',
'Beltsville',
'DC',
20705 );

/* 144 */ 
INSERT INTO customers 
VALUES (
'278928',
'Brooke',
'Forlong',
'',
'800 Kildeer Drive',
'Virginia Beach',
'VA',
23452 );

/* 145 */ 
INSERT INTO customers 
VALUES (
'283515',
'Ho',
'Tsai',
'',
'635 Northwest Boulevard',
'Washington',
'DC',
20036 );

/* 146 */ 
INSERT INTO customers 
VALUES (
'285270',
'Joshua',
'Goddard',
'',
'1460 Cabell Avenue',
'Arlington',
'VA',
22204 );

/* 147 */ 
INSERT INTO customers 
VALUES (
'277841',
'Risto',
'Kasslin',
'',
'1751 Hurry Street',
'Martinsville',
'VA',
24112 );

/* 148 */ 
INSERT INTO customers 
VALUES (
'281842',
'Severino',
'Trevisani',
'',
'4203 School Street',
'Washington',
'DC',
20024 );

