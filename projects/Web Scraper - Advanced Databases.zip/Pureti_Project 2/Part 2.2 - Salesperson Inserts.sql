/* 1 */ 
INSERT INTO salespersons (salesperson_id, first_name, last_name, MI, dealer_id, hire_date) 
VALUES (
'SP424',
'Lowell',
'Lopez',
'J',
'LYO-7631',
'18-Dec-09' );

/* 2 */ 
INSERT INTO salespersons 
VALUES (
'SP716',
'Sharyn',
'Thornton',
'R',
'FGE-8272',
'20-Mar-30' );

/* 3 */ 
INSERT INTO salespersons 
VALUES (
'SP277',
'Francis',
'Ryan',
'M',
'ZKQ-3411',
'20-May-20' );

/* 4 */ 
INSERT INTO salespersons 
VALUES (
'SP482',
'Michael',
'Carter',
'J',
'MMN-8574',
'07-Jan-05' );

/* 5 */ 
INSERT INTO salespersons 
VALUES (
'SP17',
'Linda',
'Hamilton',
'B',
'JWE-6313',
'04-Jan-08' );

/* 6 */ 
INSERT INTO salespersons 
VALUES (
'SP32',
'Richard',
'Nelson',
'S',
'WQC-0160',
'19-Dec-21' );

/* 7 */ 
INSERT INTO salespersons 
VALUES (
'SP222',
'Janice',
'Mak',
'P',
'XBV-0028',
'14-Jul-04' );

/* 8 */ 
INSERT INTO salespersons 
VALUES (
'SP475',
'Virginia',
'Kern',
'R',
'ZYQ-3802',
'13-Sep-21' );

/* 9 */ 
INSERT INTO salespersons 
VALUES (
'SP177',
'Henry',
'Sewell',
'S',
'YXH-2578',
'16-Nov-10' );

/* 10 */ 
INSERT INTO salespersons 
VALUES (
'SP202',
'Ronald',
'Gonzalez',
'J',
'NGB-4371',
'20-Apr-16' );

/* 11 */ 
INSERT INTO salespersons 
VALUES (
'SP160',
'Augusta',
'Say',
'M',
'LAC-2227',
'08-May-19' );

/* 12 */ 
INSERT INTO salespersons 
VALUES (
'SP224',
'Amy',
'Ponce',
'D',
'NDR-2833',
'03-Sep-10' );

/* 13 */ 
INSERT INTO salespersons 
VALUES (
'SP12',
'Diane',
'Beeman',
'C',
'XSK-7331',
'17-Feb-21' );

/* 14 */ 
INSERT INTO salespersons 
VALUES (
'SP610',
'George',
'Dunn',
'B',
'HFO-2503',
'00-Dec-15' );

/* 15 */ 
INSERT INTO salespersons 
VALUES (
'SP531',
'Michael',
'Banks',
'S',
'ZBG-5371',
'06-Oct-11' );

/* 16 */ 
INSERT INTO salespersons 
VALUES (
'SP156',
'Doris',
'Varner',
'A',
'ELX-3440',
'05-Dec-05' );

/* 17 */ 
INSERT INTO salespersons 
VALUES (
'SP470',
'Margaret',
'Santibanez',
'E',
'XCC-7751',
'21-Jan-18' );

/* 18 */ 
INSERT INTO salespersons 
VALUES (
'SP409',
'Julie',
'Natividad',
'N',
'BEI-2297',
'03-Aug-08' );

/* 19 */ 
INSERT INTO salespersons 
VALUES (
'SP644',
'Gayle',
'Hickman',
'G',
'ORP-8078',
'16-Feb-18' );

/* 20 */ 
INSERT INTO salespersons 
VALUES (
'SP956',
'Dorothy',
'Summers',
'M',
'OXC-3150',
'13-Jul-11' );

/* 21 */ 
INSERT INTO salespersons 
VALUES (
'SP825',
'Philomena',
'Gibbons',
'W',
'FTG-3501',
'01-Sep-02' );

/* 22 */ 
INSERT INTO salespersons 
VALUES (
'SP491',
'Phyllis',
'Minor',
'A',
'JWE-6313',
'06-Sep-15' );

/* 23 */ 
INSERT INTO salespersons 
VALUES (
'SP203',
'Christie',
'Armitage',
'E',
'XCC-7751',
'11-Dec-22' );

/* 24 */ 
INSERT INTO salespersons 
VALUES (
'SP253',
'Misty',
'Ramsey',
'G',
'SHH-8476',
'05-Mar-29' );

/* 25 */ 
INSERT INTO salespersons 
VALUES (
'SP892',
'Elizabeth',
'Allard',
'J',
'XWS-3018',
'18-Aug-17' );

/* 26 */ 
INSERT INTO salespersons 
VALUES (
'SP718',
'Joseph',
'Shelly',
'L',
'NDR-2833',
'04-Sep-19' );

/* 27 */ 
INSERT INTO salespersons 
VALUES (
'SP66',
'Jason',
'Palmer',
'I',
'WAI-2368',
'18-Apr-18' );

/* 28 */ 
INSERT INTO salespersons 
VALUES (
'SP685',
'Carol',
'Garner',
'C',
'XVU-1597',
'18-Mar-04' );

/* 29 */ 
INSERT INTO salespersons 
VALUES (
'SP371',
'Joe',
'Smith',
'C',
'QPL-3867',
'05-Sep-10' );

/* 30 */ 
INSERT INTO salespersons 
VALUES (
'SP951',
'Rita',
'Guiterrez',
'B',
'KRA-8632',
'03-May-30' );

