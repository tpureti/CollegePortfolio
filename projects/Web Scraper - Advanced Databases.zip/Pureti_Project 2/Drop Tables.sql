DROP TABLE vehicles;
DROP TABLE customers;
DROP TABLE salespersons;
DROP TABLE sales;
DROP TABLE financing_plans;
DROP TABLE sales_financings;