--------------------------------------------------------
-- Count rows in VEHICLES
--------------------------------------------------------

SELECT COUNT(*) FROM vehicles;

--------------------------------------------------------
-- Count rows in CUSTOMERS
--------------------------------------------------------

SELECT COUNT(*) FROM customers;

--------------------------------------------------------
-- Count rows in SALES
--------------------------------------------------------

SELECT COUNT(*) FROM sales;

--------------------------------------------------------
-- Count rows in SALES FINANCING
--------------------------------------------------------

SELECT COUNT(*) FROM sales_financings;

--------------------------------------------------------
-- Via a single SELECT query display the total count 
-- of sales, and the lowest, average, and highest sale price
--------------------------------------------------------

SELECT COUNT(sale_price) as count, 
AVG(sale_price) as average_price,
MIN(sale_price) as lowest_price,
MAX(sale_price) as highest_price FROM sales;

--------------------------------------------------------
-- Via a single SELECT query display all customer IDs, 
-- names, and zip codes of customers having purchased 
-- 2 or more vehicles
--------------------------------------------------------

SELECT customers.customer_id, 
       customers.first_name,
       customers.mi,
       customers.last_name, 
       customers.zip_code
FROM customers
WHERE 1 < (SELECT COUNT(*) FROM sales
           WHERE sales.customer_id = customers.customer_id);

--------------------------------------------------------
-- Via a single SELECT query display the institution 
-- and loan type of the financing plan that was used 
-- for the most sales
--------------------------------------------------------

SELECT sub.institution, sub.loan_type, 
       COUNT(*) as most_freq_plan
FROM (SELECT fp.institution, fp.loan_type
     FROM financing_plans fp, sales_financings sf
     WHERE sf.plan_id = fp.plan_id) sub
GROUP BY sub.institution, sub.loan_type
ORDER BY most_freq_plan DESC
FETCH FIRST 1 ROW ONLY; 


--------------------------------------------------------
-- Via a single SELECT query display the make of the 
-- vehicle involved in the most sales and all customers 
-- having purchased a vehicle of that make
--------------------------------------------------------

SELECT vehicle_id,
       COUNT(*) as most_freq_car
FROM sales
GROUP BY vehicle_id
ORDER BY most_freq_car DESC
FETCH FIRST 1 ROW ONLY;

SELECT vh.make, c.customer_id
FROM sales s, vehicles vh, customers c
WHERE s.customer_id = c.customer_id 
    AND s.vehicle_id = vh.vehicle_id 
GROUP BY vh.make, c.customer_id
ORDER BY vh.make ASC;


SELECT vh.make,
    COUNT(vh.make) as freq
FROM vehicles vh, sales s
WHERE s.vehicle_id = vh.vehicle_id
GROUP BY vh.make
ORDER BY freq DESC;


SELECT sub.make, sub.freq, c.customer_id
FROM (
        SELECT vh.make, COUNT(vh.make) as freq
        FROM sales s, vehicles vh
        WHERE s.vehicle_id = vh.vehicle_id
        GROUP BY vh.make
      ) sub
--GROUP BY sub.make, sub.customer_id
ORDER BY sub.freq DESC;
    
--------------------------------------------------------
-- Via a single SELECT query display the total count of 
-- sales, by model and then by zip code, with 
-- the highest values first
--------------------------------------------------------

SELECT vh.model, COUNT(vh.model) as highest_model
FROM sales s, vehicles vh
WHERE s.vehicle_id = vh.vehicle_id 
GROUP BY vh.model
ORDER BY highest_model DESC;