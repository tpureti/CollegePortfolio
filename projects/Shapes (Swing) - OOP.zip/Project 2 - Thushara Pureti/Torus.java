
/**
 * Thushara Pureti, 1/23/22
 * Torus (class)
 * Class for the torus shape
 */
import javax.swing.*;

public class Torus extends ThreeDimensionalShape {
  protected double majorRadius;
  protected double minorRadius;
  protected String shape = "torus";

  // default constructor
  public Torus() {
  }

  // constructor
  public Torus(double major, double minor) {
    majorRadius = major;
    minorRadius = minor;
  }

  // method to calculate the torus's volume
  @Override
  public double calculateVolume() {
    volume = (Math.PI * Math.pow(minorRadius, 2)) * (2.0 * Math.PI * majorRadius);
    return volume;
  }

  // method to construct a torus using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog,
          "You have selected a " + shape + "\nWhat is the major radius?");
      if (input != null) {
        String input2 = JOptionPane.showInputDialog(dialog,
            "You have selected a " + shape + "\nWhat is the minor radius?");
        if (input2 != null) {
          Double major = Double.parseDouble(input);
          Double minor = Double.parseDouble(input2);
          Torus torus = new Torus(major, minor);
          JOptionPane.showMessageDialog(dialog, torus.toString());
        }
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display torus's info
  @Override
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".";
  }
}
