
/**
 * Thushara Pureti, 1/23/22
 * Cube (class)
 * Class for the cube shape
 */
import javax.swing.*;

public class Cube extends ThreeDimensionalShape {
  protected double side;
  protected String shape = "CUBE";

  // default constructor
  public Cube() {
  }

  // constructor
  public Cube(double side) {
    this.side = side;
  }

  // method to calculate the cube's volume
  @Override
  public double calculateVolume() {
    volume = Math.pow(side, 3);
    return volume;
  }

  // method to construct a cube using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog,
          "You have selected a " + shape + "\nWhat is the side length?");
      if (input != null) {
        Double side = Double.parseDouble(input);
        Cube cube = new Cube(side);
        JOptionPane.showMessageDialog(dialog, cube.toString());
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display cube's info
  @Override
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".";
  }
}
