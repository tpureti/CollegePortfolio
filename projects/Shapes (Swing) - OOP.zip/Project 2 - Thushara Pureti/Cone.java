
/**
 * Thushara Pureti, 1/23/22
 * Cone (class)
 * Class for the cone shape
 */
import javax.swing.*;

public class Cone extends ThreeDimensionalShape {
  protected double radius;
  protected double height;
  protected String shape = "CONE";

  // default constructor
  public Cone() {
  }

  // constructor
  public Cone(double radius, double height) {
    this.radius = radius;
    this.height = height;
  }

  // method to calculate the cone's volume
  @Override
  public double calculateVolume() {
    volume = (Math.PI * Math.pow(radius, 2)) * (height / 3.0);
    return volume;
  }

  // method to construct a cone using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog, "You have selected a " + shape + "\nWhat is the radius?");
      if (input != null) {
        String input2 = JOptionPane.showInputDialog(dialog, "What is the height?");
        if (input2 != null) {
          Double radius = Double.parseDouble(input);
          Double height = Double.parseDouble(input2);
          Cone cone = new Cone(radius, height);
          JOptionPane.showMessageDialog(dialog, cone.toString());
        }
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display cone's info
  @Override
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".";
  }
}
