
/**
 * Thushara Pureti, 1/23/22
 * Circle (class)
 * Class for the circle shape
 */
import java.lang.Math;

import javax.swing.*;

public class Circle extends TwoDimensionalShape {
  protected double radius;
  protected String shape = "CIRCLE";

  // default constructor
  public Circle() {
  }

  // constructor
  public Circle(double radius) {
    this.radius = radius;
  }

  // method to calculate the circle's area
  @Override
  public double calculateArea() {
    area = Math.PI * Math.pow(radius, 2);
    return area;
  }

  // method to construct a circle using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog, "You have selected a " + shape + "\nWhat is the radius?");
      if (input != null) {
        Double radius = Double.parseDouble(input);
        Circle circle = new Circle(radius);
        JOptionPane.showMessageDialog(dialog, circle.toString());
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display circle's info
  @Override
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(calculateArea()) + ".";
  }
}
