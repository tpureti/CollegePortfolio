
/**
 * Thushara Pureti, 1/23/22
 * Shape (abstract class)
 * This class is the basis of all other classes and contains generic attributes that are shared by its child classes.
 */

import java.util.*;
import java.text.DecimalFormat;

abstract class Shape {
  // general attributes
  protected int numOfDimensions;
  protected String shape;
  protected double value;
  protected String error = "Input is invalid. Please enter a valid number.";
  DecimalFormat decimal = new DecimalFormat("#.##");
  Scanner stdin = new Scanner(System.in);

  // generic shape constructor
  public Shape() {
    numOfDimensions = 0;
  }

  // generic method to construct shape using user input
  public void constructShape() {
    System.out.println("\nYou have selected a " + shape);

    try {
      System.out.print("What is the value? ");
      value = stdin.nextDouble();
    } catch (InputMismatchException e) {
      System.out.println(error);
    }
  }

  // toString method
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(10) + ".\n";
  }
}