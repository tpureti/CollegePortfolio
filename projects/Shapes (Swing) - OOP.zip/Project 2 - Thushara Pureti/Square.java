
/**
 * Thushara Pureti, 1/23/22
 * Square (class)
 * Class for the square shape
 */
import javax.swing.*;

public class Square extends TwoDimensionalShape {
  protected double side;
  protected String shape = "SQUARE";

  // default constructor
  public Square() {
  }

  // constructor
  public Square(double side) {
    this.side = side;
  }

  // method to calculate the square's area
  @Override
  public double calculateArea() {
    area = Math.pow(side, 2);
    return area;
  }

  // method to construct a square using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog,
          "You have selected a " + shape + "\nWhat is the side length?");
      if (input != null) {
        Double side = Double.parseDouble(input);
        Square square = new Square(side);
        JOptionPane.showMessageDialog(dialog, square.toString());
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display square's info
  @Override
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(calculateArea()) + ".";
  }
}
