
/**
 * Thushara Pureti, 1/23/22
 * TwoDimensionalShape (abstract class)
 * This class is specifically for two dimensional shapes
 */
import java.util.InputMismatchException;

abstract class TwoDimensionalShape extends Shape {
  protected double area; // attribute unique to 2D shapes

  // constructor for 2D shapes
  public TwoDimensionalShape() {
    numOfDimensions = 2;
  }

  // generic method to calculate the shape's area
  public double calculateArea() {
    return area;
  }

  // generic method to construct shape using user input
  public void constructShape() {
    System.out.println("\nYou have selected a " + shape);

    try {
      System.out.print("What is the value? ");
      value = stdin.nextDouble();
    } catch (InputMismatchException e) {
      System.out.println(error);
    }
  }

  // toString method
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(calculateArea()) + ".\n";
  }
}
