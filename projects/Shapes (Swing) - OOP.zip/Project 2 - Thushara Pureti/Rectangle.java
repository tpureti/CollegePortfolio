
/**
 * Thushara Pureti, 1/23/22
 * Rectangle (class)
 * Class for the rectangle shape
 */
import javax.swing.*;

public class Rectangle extends TwoDimensionalShape {
  protected double length;
  protected double width;
  protected String shape = "RECTANGLE";

  // default constructor
  public Rectangle() {
  }

  // constructor
  public Rectangle(double length, double width) {
    this.length = length;
    this.width = width;
  }

  // method to calculate the rectangle's area
  @Override
  public double calculateArea() {
    area = length * width;
    return area;
  }

  // method to construct a rectangle using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog, "You have selected a " + shape + "\nWhat is the length?");
      if (input != null) {
        String input2 = JOptionPane.showInputDialog(dialog, "What is the width?");
        if (input2 != null) {
          Double length = Double.parseDouble(input);
          Double width = Double.parseDouble(input2);
          Rectangle rectangle = new Rectangle(length, width);
          JOptionPane.showMessageDialog(dialog, rectangle.toString());
        }
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display rectangle's info
  @Override
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(calculateArea()) + ".";
  }
}
