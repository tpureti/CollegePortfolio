
/**
 * Thushara Pureti, 1/23/22
 * ShapeProgramGUI (main)
 * Main class where program runs in a GUI.
 */
import java.time.*;
import javax.swing.*;
import javax.swing.plaf.ColorUIResource;

import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;

public class ShapeProgramGUI extends JPanel implements ActionListener {
  private static final String CIRCLE = "CIRCLE";
  private static final String RECTANGLE = "RECTANGLE";
  private static final String SQUARE = "SQUARE";
  private static final String TRIANGLE = "TRIANGLE";
  private static final String SPHERE = "SPHERE";
  private static final String CUBE = "CUBE";
  private static final String CONE = "CONE";
  private static final String CYLINDER = "CYLINDER";
  private static final String TORUS = "TORUS";

  private JFrame dialog;

  ImageIcon circleImage = new ImageIcon("imgs/circle.png"),
      rectangleImage = new ImageIcon("imgs/rectangle.png"),
      squareImage = new ImageIcon("imgs/square.png"),
      triangleImage = new ImageIcon("imgs/triangle.png"),
      sphereImage = new ImageIcon("imgs/sphere.png"),
      cubeImage = new ImageIcon("imgs/cube.png"),
      coneImage = new ImageIcon("imgs/cone.png"),
      cylinderImage = new ImageIcon("imgs/cylinder.png"),
      torusImage = new ImageIcon("imgs/torus.png");

  public ShapeProgramGUI(JFrame frame) {
    dialog = frame;

    // create buttons and set action command
    JButton constructCircle = createButtons(CIRCLE);
    constructCircle.setActionCommand(CIRCLE);
    JButton constructRectangle = createButtons(RECTANGLE);
    constructRectangle.setActionCommand(RECTANGLE);
    JButton constructSquare = createButtons(SQUARE);
    constructSquare.setActionCommand(SQUARE);
    JButton constructTriangle = createButtons(TRIANGLE);
    constructTriangle.setActionCommand(TRIANGLE);
    JButton constructSphere = createButtons(SPHERE);
    constructSphere.setActionCommand(SPHERE);
    JButton constructCube = createButtons(CUBE);
    constructCube.setActionCommand(CUBE);
    JButton constructCone = createButtons(CONE);
    constructCone.setActionCommand(CONE);
    JButton constructCylinder = createButtons(CYLINDER);
    constructCylinder.setActionCommand(CYLINDER);
    JButton constructTorus = createButtons(TORUS);
    constructTorus.setActionCommand(TORUS);

    // create panels for each shape
    JPanel circlePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(circlePanel, constructCircle, circleImage);
    JPanel rectanglePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(rectanglePanel, constructRectangle, rectangleImage);
    JPanel squarePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(squarePanel, constructSquare, squareImage);
    JPanel trianglePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(trianglePanel, constructTriangle, triangleImage);
    JPanel spherePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(spherePanel, constructSphere, sphereImage);
    JPanel cubePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(cubePanel, constructCube, cubeImage);
    JPanel conePanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(conePanel, constructCone, coneImage);
    JPanel cylinderPanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(cylinderPanel, constructCylinder, cylinderImage);
    JPanel torusPanel = new JPanel(new BorderLayout(10, 10));
    createShapePanel(torusPanel, constructTorus, torusImage);

    JPanel introPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    introPanel.setBorder(BorderFactory.createEmptyBorder(25, 10, 0, 10));
    introPanel.setBackground(new ColorUIResource(255, 255, 255));
    JTextArea intro = new JTextArea("Welcome to the shapes program. Please click on a shape to construct.");
    introPanel.add(intro);

    // add shapes + buttons to panel
    JPanel panelOne = new JPanel(new FlowLayout(FlowLayout.CENTER));
    panelOne.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
    panelOne.setBackground(new ColorUIResource(255, 255, 255));
    panelOne.add(circlePanel);
    panelOne.add(rectanglePanel);
    panelOne.add(squarePanel);

    JPanel panelTwo = new JPanel(new FlowLayout(FlowLayout.CENTER));
    panelTwo.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
    panelTwo.setBackground(new ColorUIResource(255, 255, 255));
    panelTwo.add(trianglePanel);
    panelTwo.add(spherePanel);
    panelTwo.add(cubePanel);

    JPanel panelThree = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 5));
    panelThree.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
    panelThree.setBackground(new ColorUIResource(255, 255, 255));
    panelThree.add(conePanel);
    panelThree.add(cylinderPanel);
    panelThree.add(torusPanel);

    add(introPanel);
    add(panelOne);
    add(panelTwo);
    add(panelThree);
  }

  // method to create panel for each shape
  protected static void createShapePanel(JPanel shape, JButton button, ImageIcon thumbImg) {
    // create border for spacing
    shape.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 25));
    // set background to white
    shape.setBackground(new ColorUIResource(255, 255, 255));
    // add thumbnail
    shape.add(new JLabel(thumbImg), BorderLayout.NORTH);
    // add button
    shape.add(button, BorderLayout.SOUTH);
  }

  // method to create buttons
  protected JButton createButtons(String buttonLabel) {
    JButton button = new JButton(buttonLabel);
    button.setActionCommand(buttonLabel);
    button.addActionListener(this);
    return button;
  }

  public void actionPerformed(ActionEvent e) {
    String button = e.getActionCommand();

    // if CIRCLE is pressed
    if (CIRCLE.equals(button)) {
      Circle circle = new Circle();
      circle.constructShape(dialog);
    }
    // if RECTANGLE is pressed
    else if (RECTANGLE.equals(button)) {
      Rectangle rectangle = new Rectangle();
      rectangle.constructShape(dialog);
    }
    // if SQUARE is pressed
    else if (SQUARE.equals(button)) {
      Square square = new Square();
      square.constructShape(dialog);
    }

    // if TRIANGLE is pressed
    else if (TRIANGLE.equals(button)) {
      Triangle triangle = new Triangle();
      triangle.constructShape(dialog);
    }
    // if SPHERE is pressed
    else if (SPHERE.equals(button)) {
      Sphere sphere = new Sphere();
      sphere.constructShape(dialog);
    }
    // if CUBE is pressed
    else if (CUBE.equals(button)) {
      Cube cube = new Cube();
      cube.constructShape(dialog);
    }
    // if CONE is pressed
    else if (CONE.equals(button)) {
      Cone cone = new Cone();
      cone.constructShape(dialog);
    }
    // if CYLINDER is pressed
    else if (CYLINDER.equals(button)) {
      Cylinder cylinder = new Cylinder();
      cylinder.constructShape(dialog);
    }
    // if TORUS is pressed
    else if (TORUS.equals(button)) {
      Torus torus = new Torus();
      torus.constructShape(dialog);
    }
  }

  public static void main(String[] args) {
    // create frame window
    JFrame frame = new JFrame("Shape Program");
    frame.setAlwaysOnTop(true);
    // exits on close and shows dialog with date & time
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        JOptionPane.showMessageDialog(frame, closeProgram());
      }
    });
    // create and set up content panel
    final ShapeProgramGUI contentPane = new ShapeProgramGUI(frame);
    contentPane.setOpaque(true);
    frame.setContentPane(contentPane);
    frame.setLocation(400, 50);
    contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

    // display window
    frame.pack();
    frame.setVisible(true);
  }

  // method to display date and time
  public static String closeProgram() {
    // get date and time
    LocalDate date = LocalDate.now();
    LocalTime time = LocalTime.now();
    // specify preferred formats
    DateTimeFormatter formatDate = DateTimeFormatter.ofPattern("MMMM d");
    DateTimeFormatter formatTime = DateTimeFormatter.ofPattern("h:mm a");
    // format date and time
    String formattedDate = date.format(formatDate);
    String formattedTime = time.format(formatTime);
    // print goodbye message
    return "Thanks for using the program. Today is " + formattedDate + " at " + formattedTime + ".";
  }
}
