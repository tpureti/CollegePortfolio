
/**
 * Thushara Pureti, 1/23/22
 * Cylinder (class)
 * Class for the cylinder shape
 */

import javax.swing.*;

public class Cylinder extends ThreeDimensionalShape {
  protected double radius;
  protected double height;
  protected String shape = "CYLINDER";

  // default constructor
  public Cylinder() {
  }

  // constructor
  public Cylinder(double radius, double height) {
    this.radius = radius;
    this.height = height;
  }

  // method to calculate the cylinder's volume
  @Override
  public double calculateVolume() {
    volume = Math.PI * Math.pow(radius, 2) * height;
    return volume;
  }

  // method to construct a cylinder using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog, "You have selected a " + shape + "\nWhat is the radius?");
      if (input != null) {
        String input2 = JOptionPane.showInputDialog(dialog, "What is the height?");
        if (input != null) {
          Double radius = Double.parseDouble(input);
          Double height = Double.parseDouble(input2);
          Cylinder cylinder = new Cylinder(radius, height);
          JOptionPane.showMessageDialog(dialog, cylinder.toString());
        }
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display cylinder's info
  @Override
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".";
  }
}
