
/**
 * Thushara Pureti, 1/23/22
 * Sphere (class)
 * Class for the sphere shape
 */
import javax.swing.*;

public class Sphere extends ThreeDimensionalShape {
  protected double radius;
  protected String shape = "SPHERE";

  // default constructor
  public Sphere() {
  }

  // constructor
  public Sphere(double radius) {
    this.radius = radius;
  }

  // method to calculate the sphere's volume
  @Override
  public double calculateVolume() {
    volume = (Math.PI * Math.pow(radius, 3)) * (4.0 / 3.0);
    return volume;
  }

  // method to construct a sphere using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog, "You have selected a " + shape + "\nWhat is the radius?");
      if (input != null) {
        Double radius = Double.parseDouble(input);
        Sphere sphere = new Sphere(radius);
        JOptionPane.showMessageDialog(dialog, sphere.toString());
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display sphere's info
  @Override
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".";
  }
}
