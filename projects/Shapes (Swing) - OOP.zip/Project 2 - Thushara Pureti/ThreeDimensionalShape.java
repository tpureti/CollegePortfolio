
/**
 * Thushara Pureti, 1/23/22
 * TwoDimensionalShape (abstract class)
 * This class is specifically for three dimensional shapes
 */
import java.util.InputMismatchException;

abstract class ThreeDimensionalShape extends Shape {
  protected double volume;// attribute unique to 3D shapes

  // constructor for 2D shapes
  public ThreeDimensionalShape() {
    numOfDimensions = 3;
  }

  // generic method to calculate the shape's area
  public double calculateVolume() {
    return volume;
  }

  // generic method to construct shape using user input
  public void constructShape() {
    System.out.println("\nYou have selected a " + shape);

    try {
      System.out.print("What is the value? ");
      value = stdin.nextDouble();
    } catch (InputMismatchException e) {
      System.out.println(error);
    }
  }

  // toString method
  public String toString() {
    return "The volume of the " + shape + " is " + decimal.format(calculateVolume()) + ".\n";
  }
}
