
/**
 * Thushara Pureti, 1/23/22
 * Triangle (class)
 * Class for the triangle shape
 */
import javax.swing.*;

public class Triangle extends TwoDimensionalShape {
  protected double base;
  protected double height;
  protected String shape = "TRIANGLE";

  // default constructor
  public Triangle() {
  }

  // constructor
  public Triangle(double base, double height) {
    this.base = base;
    this.height = height;
  }

  // method to calculate the triangle's area
  @Override
  public double calculateArea() {
    area = base * height * .5;
    return area;
  }

  // method to construct a triangle using user input
  public void constructShape(JFrame dialog) {
    try {
      String input = JOptionPane.showInputDialog(dialog,
          "You have selected a " + shape + "\nWhat is the base?");
      if (input != null) {
        String input2 = JOptionPane.showInputDialog(dialog, "What is the height?");
        if (input2 != null) {
          Double base = Double.parseDouble(input);
          Double height = Double.parseDouble(input2);
          Triangle triangle = new Triangle(base, height);
          JOptionPane.showMessageDialog(dialog, triangle.toString());
        }
      }
    } catch (Exception o) {
      JOptionPane.showMessageDialog(dialog, error);
    }
  }

  // method to display triangle's info
  @Override
  public String toString() {
    return "The area of the " + shape + " is " + decimal.format(calculateArea()) + ".";
  }
}
